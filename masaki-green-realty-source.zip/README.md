# Masaki Green Realty: frontend presentation prototype

A frontend-only client presentation of the Masaki Green Realty website, built with React + Vite. It has no backend, no database and no API. Everything that looks interactive runs in the browser on sample data.

## Commands

```bash
npm install       # once
npm run dev       # local development server
npm run build     # production build -> dist/
npm run preview   # serve dist/ locally to test it
```

See **CPANEL_DEPLOYMENT.md** for how to upload to cPanel.

## Where things live

| Path | What |
|---|---|
| `src/data/company.js` | Verified company facts, services and contact details (from the company profile and requirements v1.1) |
| `src/data/properties.js` | **Sample** property listings, the 9 approved categories and the statuses |
| `src/data/articles.js` | **Sample** Insights articles |
| `src/data/faqs.js` | FAQ content |
| `src/assets/logo*.jpg` | The supplied logo (only resized proportionally) |
| `src/assets/photos/` | Drop real photos here (see below) |
| `src/components/` | Header, footer, property card, forms, image component, icons |
| `src/pages/` | All pages |
| `src/lib/store.jsx` | Saved, compare and recently viewed (browser localStorage) |
| `src/styles.css` | All styling; the brand tokens are at the top |

## Replacing the illustrations with photos

Property images are currently illustrations. To use photos, create `src/assets/photos/` and add files named after the image key, for example `villa.jpg`, `living.jpg`, `kitchen.jpg` or `hero.jpg`. Then rebuild. Any key with a matching photo uses the photo automatically. Use licensed images only, and do not present stock photos as a specific listed property.

## Rules this prototype follows

- **Brand colours:** navy `#07274e`, green `#238411` and white, plus neutral greys only.
- **Prices:** shown in each property's own currency (TZS or USD), never converted. The compare page warns when currencies are mixed.
- **Availability:** Sold, Rented and Unavailable properties are hidden from listings.
- **Content:** no invented company history, statistics, awards or testimonials. Sample content is labelled as sample.
- **Email:** only `info@masakigreenrealty.co.tz` is shown. The other proposed addresses wait for confirmation.
- **Forms:** they never claim a message was delivered.
