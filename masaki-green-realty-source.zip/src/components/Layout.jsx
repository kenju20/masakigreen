import { useEffect, useState } from 'react'
import { Link, NavLink, useLocation } from 'react-router-dom'
import logo from '../assets/logo-520.jpg'
import { COMPANY, SERVICES, waLink } from '../data/company'
import { CATEGORIES } from '../data/properties'
import { useStore } from '../lib/store'
import Icon from './Icon'
import Newsletter from './Newsletter'

const NAV = [
  ['/', 'Home'],
  ['/properties', 'Properties'],
  ['/services', 'Services'],
  ['/about', 'About Us'],
  ['/insights', 'Insights'],
  ['/faq', 'FAQ'],
  ['/contact', 'Contact'],
]

export function DemoBar() {
  const [open, setOpen] = useState(() => {
    try { return sessionStorage.getItem('mgr_demo_bar') !== 'closed' } catch { return true }
  })
  if (!open) return null
  return (
    <div className="demobar">
      <div className="container demobar-in">
        <span><Icon name="info" size={16} /> <strong>Preview website.</strong> Listings marked “Sample” and the Insights articles are demonstration content.</span>
        <button aria-label="Dismiss notice" onClick={() => { setOpen(false); try { sessionStorage.setItem('mgr_demo_bar', 'closed') } catch { /* ignore */ } }}><Icon name="x" size={16} /></button>
      </div>
    </div>
  )
}

export function Header() {
  const { saved, compare } = useStore()
  const [menu, setMenu] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const loc = useLocation()
  useEffect(() => setMenu(false), [loc.pathname])
  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 8)
    on(); window.addEventListener('scroll', on, { passive: true })
    return () => window.removeEventListener('scroll', on)
  }, [])
  useEffect(() => { document.body.style.overflow = menu ? 'hidden' : '' }, [menu])

  return (
    <>
      <div className="topbar">
        <div className="container topbar-in">
          <span><Icon name="pin" size={15} /> {COMPANY.addressLine}</span>
          <span className="topbar-r">
            <a href={COMPANY.phoneHref}><Icon name="phone" size={15} /> {COMPANY.phoneDisplay}</a>
            <a href={`mailto:${COMPANY.email}`} className="hide-md"><Icon name="mail" size={15} /> {COMPANY.email}</a>
          </span>
        </div>
      </div>
      <header className={`header ${scrolled ? 'is-scrolled' : ''}`}>
        <div className="container header-in">
          <Link to="/" className="brand" aria-label="Masaki Green Realty — home">
            <img src={logo} alt="Masaki Green Realty" width="520" height="340" />
          </Link>
          <nav className={`nav ${menu ? 'open' : ''}`} aria-label="Main">
            <button className="icon-btn nav-close" onClick={() => setMenu(false)} aria-label="Close menu"><Icon name="x" /></button>
            {NAV.map(([to, label]) => (
              <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => (isActive ? 'active' : '')}>{label}</NavLink>
            ))}
            <div className="nav-mobile-extra">
              <a className="btn btn-green btn-block" href={waLink('Hello Masaki Green Realty, I have a property enquiry.')} target="_blank" rel="noopener noreferrer"><Icon name="whatsapp" /> WhatsApp us</a>
              <a className="btn btn-outline btn-block" href={COMPANY.phoneHref}><Icon name="phone" /> {COMPANY.phoneDisplay}</a>
            </div>
          </nav>
          <div className="header-actions">
            <Link to="/saved" className="icon-btn" aria-label={`Saved properties (${saved.length})`} title="Saved properties">
              <Icon name="heart" />{saved.length > 0 && <span className="count">{saved.length}</span>}
            </Link>
            <Link to="/compare" className="icon-btn" aria-label={`Compare properties (${compare.length})`} title="Compare">
              <Icon name="compare" />{compare.length > 0 && <span className="count">{compare.length}</span>}
            </Link>
            <Link to="/contact" className="btn btn-green btn-sm hide-sm">Enquire</Link>
            <button className="icon-btn burger" aria-label={menu ? 'Close menu' : 'Open menu'} aria-expanded={menu} onClick={() => setMenu((m) => !m)}>
              <Icon name={menu ? 'x' : 'menu'} />
            </button>
          </div>
        </div>
      </header>
      {menu && <div className="nav-scrim" onClick={() => setMenu(false)} />}
    </>
  )
}

export function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-news">
          <div>
            <h3>Property insights in your inbox</h3>
            <p>Occasional guides and updates from Masaki Green Realty.</p>
          </div>
          <Newsletter dark />
        </div>
        <div className="footer-grid">
          <div className="footer-brand">
            <Link to="/" className="footer-logo"><img src={logo} alt="Masaki Green Realty" width="520" height="340" loading="lazy" /></Link>
            <p>{COMPANY.promise} Property sales, rentals, management and investment advisory, from Masaki, Dar es Salaam, serving clients across Tanzania.</p>
          </div>
          <div>
            <h4>Properties</h4>
            <ul>
              <li><Link to="/properties?tx=sale">For Sale</Link></li>
              <li><Link to="/properties?tx=rent">For Rent</Link></li>
              {CATEGORIES.slice(0, 5).map((c) => <li key={c.slug}><Link to={`/properties?cat=${encodeURIComponent(c.name)}`}>{c.name}</Link></li>)}
            </ul>
          </div>
          <div>
            <h4>Company</h4>
            <ul>
              <li><Link to="/about">About Us</Link></li>
              {SERVICES.map((s) => <li key={s.slug}><Link to={`/services#${s.slug}`}>{s.name}</Link></li>)}
              <li><Link to="/insights">Insights</Link></li>
              <li><Link to="/faq">FAQ</Link></li>
            </ul>
          </div>
          <div>
            <h4>Contact</h4>
            <ul className="footer-contact">
              <li><Icon name="pin" size={16} /><span>{COMPANY.address.join(', ')}</span></li>
              <li><Icon name="phone" size={16} /><a href={COMPANY.phoneHref}>{COMPANY.phoneDisplay}</a></li>
              <li><Icon name="whatsapp" size={16} /><a href={waLink()} target="_blank" rel="noopener noreferrer">WhatsApp {COMPANY.whatsappDisplay}</a></li>
              <li><Icon name="mail" size={16} /><a href={`mailto:${COMPANY.email}`}>{COMPANY.email}</a></li>
            </ul>
          </div>
        </div>
        <div className="footer-bottom">
          <span>© {new Date().getFullYear()} {COMPANY.name}. All rights reserved.</span>
          <span className="footer-legal">
            <Link to="/privacy">Privacy Policy</Link>
            <Link to="/terms">Terms &amp; Conditions</Link>
            <Link to="/cookies">Cookies</Link>
          </span>
        </div>
      </div>
    </footer>
  )
}

export function FloatingWhatsApp() {
  return (
    <a className="wa-float" href={waLink('Hello Masaki Green Realty, I have a property enquiry.')} target="_blank" rel="noopener noreferrer" aria-label="Chat with us on WhatsApp">
      <Icon name="whatsapp" size={28} />
    </a>
  )
}

export function Toasts() {
  const { toasts } = useStore()
  return (
    <div className="toasts" role="status" aria-live="polite">
      {toasts.map((t) => <div key={t.id} className={`toast toast-${t.tone}`}><Icon name={t.tone === 'warn' ? 'info' : 'check'} size={18} />{t.msg}</div>)}
    </div>
  )
}

export function CompareTray() {
  const { compare, toggleCompare, clearCompare } = useStore()
  const loc = useLocation()
  if (!compare.length || loc.pathname === '/compare') return null
  return (
    <div className="compare-tray">
      <div className="container compare-tray-in">
        <span><Icon name="compare" size={18} /> <strong>{compare.length}</strong> of 4 selected for comparison</span>
        <div className="compare-chips">
          {compare.map((r) => (
            <button key={r} className="chip-x" onClick={() => toggleCompare(r)} aria-label={`Remove ${r}`}>{r} <Icon name="x" size={14} /></button>
          ))}
        </div>
        <div className="compare-tray-actions">
          <button className="btn btn-ghost-light btn-sm" onClick={clearCompare}>Clear</button>
          <Link to="/compare" className="btn btn-green btn-sm">Compare now</Link>
        </div>
      </div>
    </div>
  )
}

export function Breadcrumbs({ items }) {
  return (
    <nav className="crumbs" aria-label="Breadcrumb">
      <ol>
        {items.map(([label, to], i) => (
          <li key={i}>{to && i < items.length - 1 ? <Link to={to}>{label}</Link> : <span aria-current="page">{label}</span>}</li>
        ))}
      </ol>
    </nav>
  )
}

export function PageHero({ eyebrow, title, text, crumbs }) {
  return (
    <section className="page-hero">
      <div className="container">
        {crumbs && <Breadcrumbs items={crumbs} />}
        {eyebrow && <span className="eyebrow eyebrow-light">{eyebrow}</span>}
        <h1>{title}</h1>
        {text && <p>{text}</p>}
      </div>
    </section>
  )
}

export function SectionHead({ eyebrow, title, text, center, action }) {
  return (
    <div className={`section-head ${center ? 'center' : ''} ${action ? 'with-action' : ''}`}>
      <div>
        {eyebrow && <span className="eyebrow">{eyebrow}</span>}
        <h2>{title}</h2>
        {text && <p>{text}</p>}
      </div>
      {action}
    </div>
  )
}

export function usePageTitle(title, description) {
  useEffect(() => {
    document.title = title ? `${title} | ${COMPANY.name}` : `${COMPANY.name} | Buy. Sell. Invest.`
    const m = document.querySelector('meta[name="description"]')
    if (m && description) m.setAttribute('content', description)
  }, [title, description])
}
