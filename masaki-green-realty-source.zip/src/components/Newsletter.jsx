import { NewsletterForm } from './Widgets'
export default NewsletterForm
