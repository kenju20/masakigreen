import { useState } from 'react'
import { Link } from 'react-router-dom'
import { COMPANY, ENQUIRY_TYPES, waLink } from '../data/company'
import { bedsText, formatPrice, location, rentSuffix, sizeLabel, txLabel } from '../lib/format'
import { useStore } from '../lib/store'
import Icon from './Icon'
import PropertyImage from './PropertyImage'

/* ---------------- Property card ---------------- */
export function PropertyCard({ p, layout = 'grid' }) {
  const { saved, compare, toggleSaved, toggleCompare } = useStore()
  const isSaved = saved.includes(p.ref)
  const inCompare = compare.includes(p.ref)
  return (
    <article className={`pcard pcard-${layout}`}>
      <Link to={`/property/${p.slug}`} className="pcard-media" aria-label={`View ${p.title}`}>
        <PropertyImage img={p.gallery[0]} alt={`${p.title} in ${p.area}`} label={false} />
        <span className="pcard-badges">
          <span className={`badge badge-${p.tx}`}>{txLabel(p.tx)}</span>
          {p.featured && <span className="badge badge-feat"><Icon name="star" size={12} /> Featured</span>}
          {p.status === 'Reserved' && <span className="badge badge-reserved">Reserved</span>}
          {p.isNew && <span className="badge badge-new">New</span>}
        </span>
        {p.sample && <span className="pcard-sample">Sample listing</span>}
        {p.imageNote && <span className="pcard-sample">Artist’s impression</span>}
      </Link>
      <button className={`pcard-heart ${isSaved ? 'on' : ''}`} onClick={() => toggleSaved(p.ref)} aria-pressed={isSaved} aria-label={isSaved ? 'Remove from saved' : 'Save property'}>
        <Icon name="heart" size={18} />
      </button>
      <div className="pcard-body">
        <div className="pcard-top">
          <span className="pcard-cat">{p.category}</span>
          <span className="pcard-ref">{p.ref}</span>
        </div>
        <h3><Link to={`/property/${p.slug}`}>{p.title}</Link></h3>
        <p className="pcard-loc"><Icon name="pin" size={15} /> {location(p)}</p>
        <div className="pcard-price">
          <strong>{formatPrice(p)}</strong>{rentSuffix(p) && <small>{rentSuffix(p)}</small>}
          {p.negotiable && p.priceDisplay !== 'request' && <span className="neg">Negotiable</span>}
        </div>
        <ul className="pcard-specs">
          {bedsText(p) && <li><Icon name="bed" size={16} /> {bedsText(p)}</li>}
          {p.baths != null && <li><Icon name="bath" size={16} /> {p.baths} {p.baths === 1 ? 'Bath' : 'Baths'}</li>}
          {sizeLabel(p) && <li><Icon name="ruler" size={16} /> {sizeLabel(p)}</li>}
          {!bedsText(p) && p.baths == null && !sizeLabel(p) && <li><Icon name="building" size={16} /> {p.category}</li>}
        </ul>
        <div className="pcard-foot">
          <button className={`compare-toggle ${inCompare ? 'on' : ''}`} onClick={() => toggleCompare(p.ref)} aria-pressed={inCompare}>
            <Icon name={inCompare ? 'check' : 'compare'} size={15} /> {inCompare ? 'In comparison' : 'Compare'}
          </button>
          <Link to={`/property/${p.slug}`} className="pcard-more">Details <Icon name="arrow" size={15} /></Link>
        </div>
      </div>
    </article>
  )
}

/* ---------------- Enquiry form (frontend demonstration) ---------------- */
const emailOk = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)
const phoneOk = (v) => /^\+?[0-9\s()-]{9,}$/.test(v)

export function EnquiryForm({ property, defaultType, compact = false, title = 'Send an enquiry' }) {
  const [f, setF] = useState({
    name: '', email: '', phone: '',
    type: defaultType || (property ? (property.tx === 'sale' ? 'Buying a property' : 'Renting a property') : 'General enquiry'),
    message: property ? `I am interested in ${property.title} (${property.ref}). Please send me more information.` : '',
    consent: false, website: '',
  })
  const [errors, setErrors] = useState({})
  const [state, setState] = useState('idle') // idle | sending | done
  const set = (k) => (e) => setF((x) => ({ ...x, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value }))

  function validate() {
    const e = {}
    if (f.name.trim().length < 2) e.name = 'Please enter your full name.'
    if (!f.email.trim() && !f.phone.trim()) e.phone = 'Please give a phone number or email address.'
    if (f.email.trim() && !emailOk(f.email.trim())) e.email = 'Please enter a valid email address.'
    if (f.phone.trim() && !phoneOk(f.phone.trim())) e.phone = 'Please enter a valid phone number, e.g. +255 7XX XXX XXX.'
    if (f.message.trim().length < 10) e.message = 'Please add a short message (at least 10 characters).'
    if (!f.consent) e.consent = 'Please confirm you agree to be contacted about your enquiry.'
    return e
  }
  function submit(ev) {
    ev.preventDefault()
    if (f.website) return // honeypot: bots fill hidden fields
    const e = validate()
    setErrors(e)
    if (Object.keys(e).length) {
      const first = ev.currentTarget.querySelector('[aria-invalid="true"]')
      first?.focus()
      return
    }
    setState('sending')
    setTimeout(() => setState('done'), 900)
  }
  const waText = `Hello Masaki Green Realty,\n\nName: ${f.name}\nPhone: ${f.phone || '-'}\nEmail: ${f.email || '-'}\nEnquiry: ${f.type}${property ? `\nProperty: ${property.title} (${property.ref})` : ''}\n\n${f.message}`

  if (state === 'done') {
    return (
      <div className="form-card form-done" role="status">
        <div className="done-icon"><Icon name="check" size={28} /></div>
        <h3>Your enquiry is ready</h3>
        <p className="demo-note"><Icon name="info" size={16} /> <span><strong>One more step:</strong> online form delivery is not switched on yet, so this enquiry has <strong>not</strong> been sent. Tap “Send on WhatsApp” below to send it to our team with your details filled in.</span></p>
        <p>Or call us on {COMPANY.phoneDisplay}.</p>
        <div className="btn-row">
          <a className="btn btn-green" href={waLink(waText)} target="_blank" rel="noopener noreferrer"><Icon name="whatsapp" /> Send on WhatsApp</a>
          <button className="btn btn-outline" onClick={() => setState('idle')}>Edit enquiry</button>
        </div>
      </div>
    )
  }

  const err = (k) => errors[k] && <span className="field-err" id={`${k}-err`}>{errors[k]}</span>
  return (
    <form className={`form-card ${compact ? 'compact' : ''}`} onSubmit={submit} noValidate>
      <h3>{title}</h3>
      {property && <p className="form-about">Enquiring about <strong>{property.title}</strong> · Ref {property.ref}</p>}
      <div className="hp" aria-hidden="true"><label>Website<input tabIndex={-1} autoComplete="off" value={f.website} onChange={set('website')} /></label></div>
      <div className="field">
        <label htmlFor={`n-${property?.ref || 'g'}`}>Full name *</label>
        <input id={`n-${property?.ref || 'g'}`} value={f.name} onChange={set('name')} aria-invalid={!!errors.name} aria-describedby={errors.name ? 'name-err' : undefined} autoComplete="name" />
        {err('name')}
      </div>
      <div className="field-row">
        <div className="field">
          <label htmlFor={`p-${property?.ref || 'g'}`}>Phone</label>
          <input id={`p-${property?.ref || 'g'}`} type="tel" placeholder="+255 7XX XXX XXX" value={f.phone} onChange={set('phone')} aria-invalid={!!errors.phone} aria-describedby={errors.phone ? 'phone-err' : undefined} autoComplete="tel" />
          {err('phone')}
        </div>
        <div className="field">
          <label htmlFor={`e-${property?.ref || 'g'}`}>Email</label>
          <input id={`e-${property?.ref || 'g'}`} type="email" value={f.email} onChange={set('email')} aria-invalid={!!errors.email} aria-describedby={errors.email ? 'email-err' : undefined} autoComplete="email" />
          {err('email')}
        </div>
      </div>
      {!property && (
        <div className="field">
          <label htmlFor="etype">Enquiry type</label>
          <select id="etype" value={f.type} onChange={set('type')}>{ENQUIRY_TYPES.map((t) => <option key={t}>{t}</option>)}</select>
        </div>
      )}
      <div className="field">
        <label htmlFor={`m-${property?.ref || 'g'}`}>Message *</label>
        <textarea id={`m-${property?.ref || 'g'}`} rows={compact ? 3 : 5} value={f.message} onChange={set('message')} aria-invalid={!!errors.message} aria-describedby={errors.message ? 'message-err' : undefined} />
        {err('message')}
      </div>
      <label className="check">
        <input type="checkbox" checked={f.consent} onChange={set('consent')} aria-invalid={!!errors.consent} />
        <span>I agree to be contacted about this enquiry and have read the <Link to="/privacy">Privacy Policy</Link>.</span>
      </label>
      {err('consent')}
      <button className="btn btn-green btn-block" type="submit" disabled={state === 'sending'}>
        {state === 'sending' ? <><span className="spinner" /> Preparing…</> : 'Send enquiry'}
      </button>
      <p className="form-fine">Your enquiry is sent through WhatsApp after you submit.</p>
    </form>
  )
}

/* ---------------- Newsletter (frontend demonstration) ---------------- */
export function NewsletterForm({ dark }) {
  const [email, setEmail] = useState('')
  const [msg, setMsg] = useState(null)
  function submit(e) {
    e.preventDefault()
    if (!emailOk(email.trim())) return setMsg({ tone: 'err', text: 'Please enter a valid email address.' })
    setMsg({ tone: 'ok', text: 'Thank you. Newsletter sign-up is coming soon, so no subscription has been created yet.' })
    setEmail('')
  }
  return (
    <form className={`newsletter ${dark ? 'dark' : ''}`} onSubmit={submit} noValidate>
      <label htmlFor={dark ? 'nl-f' : 'nl'} className="sr-only">Email address</label>
      <div className="newsletter-row">
        <input id={dark ? 'nl-f' : 'nl'} type="email" placeholder="Your email address" value={email} onChange={(e) => { setEmail(e.target.value); setMsg(null) }} />
        <button className="btn btn-green" type="submit">Subscribe</button>
      </div>
      {msg && <p className={`nl-msg ${msg.tone}`} role="status">{msg.text}</p>}
    </form>
  )
}

/* ---------------- Accordion ---------------- */
export function Accordion({ items, idPrefix = 'faq' }) {
  const [open, setOpen] = useState(0)
  return (
    <div className="accordion">
      {items.map((it, i) => {
        const on = open === i
        return (
          <div key={i} className={`acc-item ${on ? 'open' : ''}`}>
            <h3>
              <button aria-expanded={on} aria-controls={`${idPrefix}-${i}`} id={`${idPrefix}-b-${i}`} onClick={() => setOpen(on ? -1 : i)}>
                {it.q}<Icon name="down" size={20} />
              </button>
            </h3>
            <div id={`${idPrefix}-${i}`} role="region" aria-labelledby={`${idPrefix}-b-${i}`} className="acc-panel" hidden={!on}>
              <p>{it.a}</p>
            </div>
          </div>
        )
      })}
    </div>
  )
}

export function Empty({ icon = 'search', title, text, children }) {
  return (
    <div className="empty">
      <div className="empty-icon"><Icon name={icon} size={28} /></div>
      <h3>{title}</h3>
      {text && <p>{text}</p>}
      {children}
    </div>
  )
}
