import { useId } from 'react'

/*
  PropertyImage
  -------------
  Shows a real photograph when one exists, otherwise a styled architectural
  illustration so the prototype still looks complete.

  To use real photos: drop files into src/assets/photos/ named after the image key
  (e.g. villa.jpg, living.jpg, mgr-0001-1.jpg). They are picked up automatically
  at build time and replace the illustration with the same key.
*/
const files = import.meta.glob('../assets/photos/*.{jpg,jpeg,png,webp}', { eager: true, import: 'default' })
const PHOTOS = Object.fromEntries(
  Object.entries(files).map(([path, url]) => [path.split('/').pop().replace(/\.\w+$/, ''), url])
)
export const hasPhoto = (key) => Boolean(PHOTOS[key])

const C = {
  navy: '#07274e', navy2: '#163d6e', navy3: '#3a5a86', green: '#238411', green2: '#2e9a1b', greenD: '#175f0a',
  wall: '#f7f5f0', wall2: '#e9e4da', glass: '#cbd8e4', glassD: '#9fb4c8', wood: '#a27b56', woodD: '#7b5a3c',
  sand: '#ece0c3', sea: '#5e86ad', sky1: '#d7e2ec', sky2: '#f3f5f7', ink: '#20304a',
}

const tree = (x, y, s = 1) => (
  <g key={`t${x}`} transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x="-4" y="-60" width="8" height="60" fill={C.woodD} />
    <circle cx="0" cy="-78" r="34" fill={C.greenD} />
    <circle cx="20" cy="-62" r="24" fill={C.green} />
    <circle cx="-18" cy="-60" r="20" fill={C.green2} />
  </g>
)
const palm = (x, y, s = 1) => (
  <g key={`p${x}`} transform={`translate(${x} ${y}) scale(${s})`} fill="none" strokeLinecap="round">
    <path d="M0 0 q8 -60 2 -120" stroke={C.woodD} strokeWidth="8" />
    {[[-60, -10], [60, -6], [-40, 30], [44, 30], [0, -40]].map(([dx, dy], i) => (
      <path key={i} d={`M2 -120 q${dx / 2} ${dy - 20} ${dx} ${dy + 20}`} stroke={C.green} strokeWidth="9" />
    ))}
  </g>
)
const windows = (x0, y0, cols, rows, w, h, gx, gy, fill = C.glass) =>
  Array.from({ length: rows * cols }, (_, i) => (
    <rect key={`w${x0}${y0}${i}`} x={x0 + (i % cols) * (w + gx)} y={y0 + Math.floor(i / cols) * (h + gy)} width={w} height={h} fill={fill} />
  ))

function Sky({ id, warm }) {
  return (
    <>
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={warm ? '#cfdbe7' : C.sky1} />
          <stop offset="1" stopColor={warm ? '#f6eedf' : C.sky2} />
        </linearGradient>
      </defs>
      <rect width="800" height="500" fill={`url(#${id})`} />
    </>
  )
}
const Lawn = ({ y = 400 }) => (
  <>
    <rect y={y} width="800" height={500 - y} fill={C.green2} />
    <rect y={y} width="800" height="8" fill={C.green} />
  </>
)
const Room = ({ floor = C.wood, wall = C.wall }) => (
  <>
    <rect width="800" height="500" fill={wall} />
    <rect y="380" width="800" height="120" fill={floor} />
    <rect y="372" width="800" height="10" fill={C.wall2} />
  </>
)

const SCENES = {
  hero: (id) => (<>
    <defs><linearGradient id={id} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#3d5f8c" /><stop offset=".65" stopColor="#9db3cb" /><stop offset="1" stopColor="#e9dcc1" /></linearGradient></defs>
    <rect width="800" height="500" fill={`url(#${id})`} />
    <circle cx="640" cy="270" r="40" fill="#f3e3bf" opacity=".9" />
    <g fill={C.navy3} opacity=".7">{[[330, 170, 40], [380, 120, 52], [440, 190, 34], [480, 140, 46], [535, 200, 32], [575, 100, 54], [640, 160, 40], [690, 130, 48], [745, 190, 40]].map(([x, y, w]) => <rect key={x} x={x} y={y} width={w} height={340 - y} />)}</g>
    <g fill={C.navy}>{[[400, 210, 46], [500, 180, 58], [600, 230, 40], [660, 200, 52], [730, 240, 50]].map(([x, y, w]) => <rect key={x} x={x} y={y} width={w} height={340 - y} />)}</g>
    <g fill="#f3e3bf" opacity=".75">{[[410, 225], [425, 245], [410, 265], [510, 195], [530, 215], [512, 240], [545, 260], [612, 250], [670, 215], [690, 240], [745, 260]].map(([x, y]) => <rect key={`${x}${y}`} x={x} y={y} width="7" height="5" />)}</g>
    <rect y="338" width="800" height="70" fill={C.sea} />
    <path d="M0 370q200-30 400-6t400-4v140H0z" fill={C.greenD} />
    <path d="M0 410q260-26 520-8t280 0v98H0z" fill={C.green} />
    {palm(735, 420, .9)}{tree(80, 412, .9)}
  </>),
  villa: (id) => (<><Sky id={id} warm /><rect y="360" width="800" height="40" fill={C.sea} opacity=".55" /><Lawn y={392} />
    <rect x="150" y="215" width="500" height="180" fill={C.wall} /><rect x="120" y="200" width="560" height="20" fill={C.navy} />
    <rect x="290" y="130" width="300" height="72" fill={C.wall2} /><rect x="270" y="116" width="340" height="16" fill={C.navy} />
    <rect x="310" y="146" width="260" height="44" fill={C.glass} /><rect x="180" y="250" width="110" height="100" fill={C.glass} />
    <rect x="510" y="250" width="110" height="100" fill={C.glass} /><rect x="365" y="270" width="70" height="125" fill={C.navy2} />
    <rect x="230" y="415" width="340" height="34" rx="4" fill="#9fc3dc" />{tree(80, 400, 1.2)}{tree(730, 400, 1.4)}</>),
  house: (id) => (<><Sky id={id} /><Lawn />
    <polygon points="400,110 650,240 150,240" fill={C.navy} /><rect x="185" y="238" width="430" height="162" fill={C.wall} />
    <rect x="220" y="275" width="90" height="70" fill={C.glass} /><rect x="490" y="275" width="90" height="70" fill={C.glass} />
    <rect x="365" y="290" width="70" height="110" fill={C.green} />{tree(90, 400, 1.2)}{tree(720, 400, 1.3)}</>),
  house2: (id) => (<><Sky id={id} warm /><Lawn />
    <polygon points="120,250 400,165 680,250" fill={C.woodD} /><rect x="150" y="248" width="500" height="152" fill="#f3ead9" />
    <rect x="190" y="280" width="80" height="64" fill={C.glass} /><rect x="530" y="280" width="80" height="64" fill={C.glass} />
    <rect x="370" y="285" width="60" height="115" fill={C.wood} />{tree(60, 400, 1.3)}{tree(740, 400)}</>),
  tower: (id) => (<><Sky id={id} /><Lawn y={420} />
    <rect x="300" y="60" width="200" height="360" fill={C.navy} />{windows(318, 80, 4, 12, 34, 18, 10, 10)}
    <rect x="130" y="210" width="150" height="210" fill={C.navy2} />{windows(146, 228, 3, 7, 30, 16, 14, 10, C.glassD)}
    <rect x="520" y="170" width="160" height="250" fill={C.navy2} />{windows(536, 188, 3, 8, 32, 16, 14, 10, C.glassD)}
    {tree(70, 420)}{tree(740, 420, 1.1)}</>),
  tower2: (id) => (<><Sky id={id} warm /><Lawn y={420} />
    <rect x="260" y="70" width="280" height="350" fill={C.wall} /><rect x="245" y="58" width="310" height="14" fill={C.navy} />
    {Array.from({ length: 7 }, (_, r) => (<g key={r}><rect x="275" y={88 + r * 46} width="250" height="26" fill={C.glass} /><rect x="260" y={118 + r * 46} width="280" height="5" fill={C.navy} /></g>))}
    {tree(150, 420, 1.3)}{tree(660, 420, 1.1)}</>),
  tower3: (id) => (<><Sky id={id} /><Lawn y={420} />
    <rect x="220" y="150" width="360" height="270" fill="#efe9de" />{windows(245, 175, 5, 5, 46, 32, 20, 18)}
    <rect x="370" y="360" width="60" height="60" fill={C.navy} />{tree(120, 420)}{tree(690, 420)}</>),
  office: (id) => (<><Sky id={id} /><Lawn y={420} />
    <rect x="200" y="70" width="400" height="350" fill={C.navy2} />
    {Array.from({ length: 10 }, (_, r) => <rect key={r} x="215" y={86 + r * 30} width="370" height="20" fill={C.glass} opacity=".9" />)}
    <rect x="360" y="370" width="80" height="50" fill={C.navy} />{tree(110, 420, 1.1)}{tree(700, 420, 1.2)}</>),
  office2: (id) => (<><Sky id={id} warm /><Lawn y={420} />
    <rect x="170" y="110" width="460" height="310" fill={C.wall} /><rect x="170" y="330" width="460" height="90" fill={C.navy} />
    {windows(195, 130, 6, 4, 54, 34, 20, 14)}{windows(195, 345, 4, 1, 90, 60, 18, 0, C.glass)}{tree(90, 420)}{tree(720, 420)}</>),
  shop: (id) => (<><Sky id={id} warm /><rect y="410" width="800" height="90" fill="#cfc8bb" />
    <rect x="120" y="140" width="560" height="270" fill="#efe5d2" /><rect x="120" y="130" width="560" height="16" fill={C.navy} />
    <rect x="160" y="230" width="200" height="150" fill={C.glass} /><rect x="440" y="230" width="200" height="150" fill={C.glass} />
    <path d="M160 230h200l-18-34H178z M440 230h200l-18-34H458z" fill={C.green} /><rect x="375" y="250" width="50" height="160" fill={C.navy2} /></>),
  warehouse: (id) => (<><Sky id={id} /><rect y="400" width="800" height="100" fill="#cfcabf" />
    <path d="M110 400V210l290-70 290 70v190z" fill={C.navy3} /><path d="M110 210l290-70 290 70" fill="none" stroke={C.navy} strokeWidth="14" />
    <rect x="180" y="290" width="150" height="110" fill={C.wall2} /><rect x="470" y="290" width="150" height="110" fill={C.wall2} />
    {[0, 1, 2, 3, 4, 5].map((i) => <rect key={i} x={180} y={300 + i * 16} width="150" height="3" fill="#bfb8aa" />)}
    {[0, 1, 2, 3, 4, 5].map((i) => <rect key={`b${i}`} x={470} y={300 + i * 16} width="150" height="3" fill="#bfb8aa" />)}</>),
  land: (id) => (<><Sky id={id} warm /><rect y="300" width="800" height="200" fill="#a9c08e" />
    <path d="M0 330q200-30 400-10t400 0v180H0z" fill={C.green2} /><path d="M0 420q300-30 800-10v90H0z" fill={C.green} />
    <rect x="270" y="350" width="260" height="90" fill="none" stroke={C.wall} strokeWidth="4" strokeDasharray="14 10" />
    {[270, 530].map((x) => <rect key={x} x={x - 4} y="340" width="8" height="24" fill={C.wall} />)}{tree(110, 330, .9)}{tree(700, 330, 1.1)}</>),
  plot: () => (<><rect width="800" height="500" fill="#b8c99d" />
    {[[60, 50, 300, 180], [400, 50, 340, 180], [60, 270, 220, 190], [320, 270, 420, 190]].map(([x, y, w, h], i) => (
      <rect key={i} x={x} y={y} width={w} height={h} fill={i === 3 ? C.green2 : '#a3b787'} stroke={C.wall} strokeWidth="3" />))}
    <rect x="0" y="236" width="800" height="28" fill="#d8ccb2" /><rect x="372" y="0" width="22" height="500" fill="#d8ccb2" />
    <rect x="320" y="270" width="420" height="190" fill="none" stroke={C.navy} strokeWidth="6" strokeDasharray="16 10" />
    <circle cx="530" cy="365" r="16" fill={C.navy} /><circle cx="530" cy="365" r="6" fill={C.wall} /></>),
  farm: (id) => (<><Sky id={id} warm /><rect y="280" width="800" height="220" fill="#b9c991" />
    {Array.from({ length: 9 }, (_, i) => <path key={i} d={`M${-100 + i * 110} 500 L${330 + i * 18} 290`} stroke={C.green} strokeWidth="14" />)}
    {tree(90, 300, .8)}{tree(150, 300, .6)}{tree(700, 300, .9)}</>),
  beach: (id) => (<><Sky id={id} warm /><rect y="270" width="800" height="70" fill={C.sea} />
    <path d="M0 330q400-24 800 0v170H0z" fill={C.sand} />
    <rect x="300" y="230" width="300" height="130" fill={C.wall} /><polygon points="280,232 450,170 620,232" fill={C.woodD} />
    <rect x="330" y="260" width="70" height="60" fill={C.glass} /><rect x="500" y="260" width="70" height="60" fill={C.glass} /><rect x="425" y="280" width="50" height="80" fill={C.wood} />
    {palm(140, 380)}{palm(230, 400, .8)}{palm(690, 390, 1.1)}</>),
  mountain: (id) => (<><Sky id={id} /><polygon points="80,400 400,90 720,400" fill={C.navy3} /><polygon points="340,150 400,90 460,150 430,142 400,160 370,142" fill={C.wall} />
    <Lawn y={395} /><rect x="230" y="300" width="340" height="100" fill="#f1e8d6" /><polygon points="210,302 400,240 590,302" fill={C.woodD} />
    <rect x="270" y="325" width="60" height="46" fill={C.glass} /><rect x="470" y="325" width="60" height="46" fill={C.glass} /><rect x="375" y="325" width="50" height="75" fill={C.wood} />
    {tree(110, 400, 1.1)}{tree(700, 400)}</>),
  living: () => (<><Room /><rect x="460" y="70" width="280" height="220" fill={C.glass} /><rect x="596" y="70" width="8" height="220" fill={C.wall} />
    <rect x="80" y="110" width="120" height="90" fill={C.navy3} opacity=".85" /><rect x="90" y="120" width="100" height="70" fill={C.wall2} />
    <rect x="90" y="300" width="360" height="80" rx="10" fill={C.navy} /><rect x="90" y="270" width="360" height="40" rx="10" fill={C.navy2} />
    <rect x="130" y="282" width="60" height="30" rx="6" fill={C.wall2} /><rect x="350" y="282" width="60" height="30" rx="6" fill={C.green} />
    <rect x="200" y="410" width="200" height="16" rx="3" fill={C.woodD} /><rect x="520" y="300" width="20" height="80" fill={C.woodD} />
    <circle cx="530" cy="290" r="34" fill={C.green} /><rect x="0" y="440" width="800" height="60" fill={C.woodD} opacity=".25" /></>),
  kitchen: () => (<><Room floor="#d9d3c7" /><rect x="60" y="70" width="680" height="110" fill={C.navy} />{windows(80, 85, 5, 1, 118, 80, 16, 0, C.navy2)}
    <rect x="60" y="250" width="680" height="130" fill={C.navy} /><rect x="60" y="240" width="680" height="14" fill={C.wall2} />
    <rect x="200" y="320" width="400" height="80" fill={C.wall} /><rect x="190" y="310" width="420" height="14" fill={C.wall2} />
    {[260, 400, 540].map((x) => <g key={x}><rect x={x} y="420" width="8" height="60" fill={C.woodD} /><rect x={x - 22} y="410" width="52" height="12" rx="4" fill={C.green} /></g>)}
    <rect x="560" y="200" width="60" height="40" fill={C.glass} /></>),
  bedroom: () => (<><Room wall="#f1ede5" /><rect x="520" y="80" width="200" height="220" fill={C.glass} /><rect x="520" y="80" width="200" height="220" fill="none" stroke={C.wall} strokeWidth="10" />
    <rect x="130" y="200" width="320" height="80" fill={C.navy} /><rect x="110" y="270" width="360" height="120" rx="8" fill={C.wall} />
    <rect x="110" y="300" width="360" height="90" rx="8" fill={C.navy2} /><rect x="150" y="250" width="110" height="40" rx="10" fill={C.wall2} /><rect x="300" y="250" width="110" height="40" rx="10" fill={C.wall2} />
    <rect x="490" y="320" width="60" height="70" fill={C.wood} /><circle cx="520" cy="300" r="18" fill={C.green} /></>),
  bath: () => (<><Room floor="#e2ddd3" wall="#eef1f3" />{Array.from({ length: 10 }, (_, i) => <rect key={i} x={i * 80} y="0" width="2" height="372" fill="#dfe4e8" />)}
    <rect x="100" y="270" width="380" height="110" rx="40" fill={C.wall} stroke={C.wall2} strokeWidth="6" /><rect x="560" y="110" width="140" height="170" rx="8" fill={C.glass} />
    <rect x="560" y="290" width="140" height="90" fill={C.navy} /><rect x="600" y="270" width="60" height="20" rx="6" fill={C.wall} /><circle cx="150" cy="220" r="26" fill={C.green} /></>),
  officeInt: () => (<><Room floor="#cfd3d8" /><rect x="0" y="60" width="800" height="230" fill={C.glass} />{[200, 400, 600].map((x) => <rect key={x} x={x} y="60" width="8" height="230" fill={C.wall} />)}
    {[90, 330, 570].map((x) => <g key={x}><rect x={x} y="330" width="160" height="12" fill={C.navy} /><rect x={x + 10} y="342" width="8" height="70" fill={C.navy} /><rect x={x + 142} y="342" width="8" height="70" fill={C.navy} />
      <rect x={x + 50} y="290" width="60" height="40" fill={C.navy2} /><rect x={x + 55} y="420" width="50" height="14" rx="5" fill={C.green} /></g>)}</>),
  officeInt2: () => (<><Room floor="#d4cfc6" /><rect x="120" y="80" width="560" height="200" fill={C.navy3} opacity=".25" /><rect x="300" y="110" width="200" height="120" fill={C.navy} />
    <rect x="140" y="320" width="520" height="40" rx="20" fill={C.woodD} />{[180, 290, 400, 510, 620].map((x) => <rect key={x} x={x - 20} y="372" width="40" height="40" rx="8" fill={C.navy2} />)}</>),
  shopInt: () => (<><Room floor="#d9d3c7" />{[60, 300, 540].map((x) => <g key={x}><rect x={x} y="110" width="200" height="270" fill={C.wall2} />{[150, 220, 290].map((y) => <rect key={y} x={x} y={y} width="200" height="8" fill={C.woodD} />)}
    {[0, 1, 2].map((i) => <rect key={i} x={x + 20 + i * 60} y="120" width="40" height="30" fill={i === 1 ? C.green : C.navy3} />)}</g>)}</>),
  warehouseInt: () => (<><rect width="800" height="500" fill="#dad6cd" /><rect y="380" width="800" height="120" fill="#bdb7aa" />
    {[80, 300, 520].map((x) => <g key={x}>{[150, 230, 310].map((y) => <rect key={y} x={x} y={y} width="200" height="8" fill={C.navy} />)}
      <rect x={x} y="140" width="8" height="240" fill={C.navy} /><rect x={x + 192} y="140" width="8" height="240" fill={C.navy} />
      {[160, 240, 320].map((y) => [0, 1, 2].map((i) => <rect key={`${y}${i}`} x={x + 14 + i * 62} y={y - 4} width="50" height="58" fill={C.wood} />))}</g>)}</>),
}

export default function PropertyImage({ img, alt = '', className = '', eager = false, label = true }) {
  const key = typeof img === 'string' ? img : img?.key
  const src = typeof img === 'object' && img?.src ? img.src : PHOTOS[key]
  const gid = useId().replace(/[^a-zA-Z0-9]/g, '')
  if (src) return <img src={src} alt={alt} className={`pimg ${className}`} loading={eager ? 'eager' : 'lazy'} decoding="async" />
  const draw = SCENES[key] || SCENES.house
  return (
    <div className={`pimg pimg-illus ${className}`} role="img" aria-label={alt ? `${alt} (illustration)` : 'Property illustration'}>
      <svg viewBox="0 0 800 500" preserveAspectRatio="xMidYMid slice">{draw(`s${gid}`)}</svg>
      {label && <span className="illus-tag">Illustration</span>}
    </div>
  )
}
