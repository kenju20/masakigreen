// Verified company information — source: Masaki Green Realty company profile
// and Website Project Requirements v1.1. Do not add facts that are not in those documents.
export const COMPANY = {
  name: 'Masaki Green Realty',
  tagline: 'Buy. Sell. Invest.',
  promise: 'Your Trusted Property Partner in Tanzania.',
  website: 'https://masakigreenrealty.co.tz',
  domain: 'masakigreenrealty.co.tz',
  phoneDisplay: '+255 657 633 698',
  phoneHref: 'tel:+255657633698',
  whatsappNumber: '255657633698',
  whatsappDisplay: '+255 657 633 698',
  // Only info@ is listed in the company profile. Other proposed addresses
  // (sales@, rentals@, management@, support@) are NOT shown until confirmed active.
  email: 'info@masakigreenrealty.co.tz',
  address: ['190 Kimweri Road', 'Masaki', 'Dar es Salaam, Tanzania'],
  addressLine: '190 Kimweri Road, Masaki, Dar es Salaam, Tanzania',
  mission: 'To make real estate simple, accessible and rewarding.',
  vision: 'To be a trusted real estate partner across Tanzania.',
  values: [
    { name: 'Trust', text: 'Building lasting relationships through reliability.' },
    { name: 'Integrity', text: 'Conducting business honestly and ethically.' },
    { name: 'Transparency', text: 'Promoting clear and open communication.' },
    { name: 'Excellence', text: 'Delivering professional and dependable services.' },
  ],
}

export const waLink = (text) =>
  `https://wa.me/${COMPANY.whatsappNumber}${text ? `?text=${encodeURIComponent(text)}` : ''}`

export const SERVICES = [
  {
    slug: 'sales',
    name: 'Property Sales',
    icon: 'home',
    short: 'Assisting clients in buying and selling residential and commercial properties through professional guidance and reliable property information.',
    long: [
      'Whether you are buying your first home, moving your family, acquiring commercial premises or selling a property you own, we guide you through each stage with clear, reliable information.',
      'We work across residential and commercial property, in both the general and premium market, so buyers can compare suitable options and sellers can reach serious prospective buyers.',
    ],
    points: ['Residential and commercial properties', 'Guidance for buyers and sellers', 'Reliable property information', 'Support from enquiry to completion'],
    interest: 'Buying a property',
    cta: 'Enquire about property sales',
  },
  {
    slug: 'rentals',
    name: 'Property Rentals',
    icon: 'key',
    short: 'Connecting property owners with prospective tenants while helping individuals and businesses find suitable rental properties.',
    long: [
      'For tenants, we help individuals, families and businesses find rental homes, apartments, offices and commercial spaces that suit their needs and budget.',
      'For property owners, we connect your property with prospective tenants and help make the letting process straightforward.',
    ],
    points: ['Residential and commercial rentals', 'Homes, apartments, offices and retail', 'Support for owners and tenants', 'Clear, open communication'],
    interest: 'Renting a property',
    cta: 'Enquire about rentals',
  },
  {
    slug: 'management',
    name: 'Property Management',
    icon: 'clipboard',
    short: 'Providing property management services to help property owners oversee their investments and maintain their properties.',
    long: [
      'Owning property is an investment that needs ongoing attention. Our property management service helps owners oversee their properties and keep them well maintained.',
      'We aim to give owners dependable support and transparent communication, so their investment is looked after.',
    ],
    points: ['Oversight of your property investment', 'Help keeping properties maintained', 'Dependable, professional service', 'Transparent communication with owners'],
    interest: 'Property management',
    cta: 'Enquire about property management',
  },
  {
    slug: 'investment',
    name: 'Real Estate Investment & Advisory',
    icon: 'trend',
    short: 'Supporting clients in exploring property investment opportunities and making informed real estate decisions.',
    long: [
      'Property can be an important long-term investment. We support individuals, businesses and investors in exploring residential, commercial and investment property opportunities across Tanzania.',
      'Our aim is to help you make informed decisions with professional property guidance.',
    ],
    points: ['Residential, commercial and investment property', 'Opportunities across Tanzania', 'Professional property guidance', 'Support for informed decisions'],
    interest: 'Investment advice',
    cta: 'Enquire about investment advisory',
  },
]

export const ENQUIRY_TYPES = [
  'Buying a property',
  'Selling a property',
  'Renting a property',
  'Letting my property',
  'Property management',
  'Investment advice',
  'General enquiry',
]
