// ============================================================
// PROPERTY DATA
// - MGR-xxxx  = ACTUAL listings supplied by Masaki Green Realty (Nov 2026)
// - SMP-xxx   = SAMPLE / demonstration listings (sample: true). Replace or
//               remove before launch. They are labelled "Sample listing" on site.
// ============================================================

// Approved property categories (Requirements v1.1 §6.1)
export const CATEGORIES = [
  { name: 'Residential', slug: 'residential', icon: 'home' },
  { name: 'Commercial', slug: 'commercial', icon: 'building' },
  { name: 'Land', slug: 'land', icon: 'map' },
  { name: 'Apartments', slug: 'apartments', icon: 'apartment' },
  { name: 'Luxury Properties', slug: 'luxury', icon: 'star' },
  { name: 'Offices', slug: 'offices', icon: 'briefcase' },
  { name: 'Retail Spaces', slug: 'retail', icon: 'store' },
  { name: 'Holiday Homes', slug: 'holiday', icon: 'sun' },
  { name: 'Industrial Properties', slug: 'industrial', icon: 'factory' },
]

// Availability statuses (§6.5). Only these two are shown as current listings.
export const PUBLIC_STATUSES = ['Available', 'Reserved']
export const ALL_STATUSES = ['Available', 'Reserved', 'Sold', 'Rented', 'Unavailable']

const photos = (ref, n) => Array.from({ length: n }, (_, i) => `${ref.toLowerCase()}-${i + 1}`)

/*
  Field notes
  - price: stored in the ORIGINAL currency. Never converted.
  - priceDisplay: 'exact' | 'from' (developments) | 'request'
  - rentTerm: 'month' | 'year' (rentals only)
  - beds/baths/size/land: null when not stated or not applicable
  - bedsLabel / sizeText: optional display overrides for developments
  - imageNote: shown under the gallery (e.g. developer renders)
  - isNew: shows the "New" badge
*/
export const PROPERTIES = [
  /* ===================== ACTUAL LISTINGS ===================== */
  {
    ref: 'MGR-0001', slug: 'furnished-5-bedroom-house-with-pool-madale',
    title: 'Furnished 5-Bedroom House with Pool', category: 'Residential', tx: 'rent',
    region: 'Dar es Salaam', city: 'Dar es Salaam', area: 'Madale',
    price: 2000, currency: 'USD', rentTerm: 'month', priceDisplay: 'exact', negotiable: false,
    beds: 5, baths: null, size: null, land: null, floors: '2 storeys',
    status: 'Available', featured: true, isNew: true, added: '2026-11-18',
    short: 'Fully furnished five-bedroom family home with swimming pool and a beautiful garden.',
    description: [
      'A fully furnished five-bedroom, two-storey house for rent in Madale, set in a walled compound with a paved driveway, a swimming pool and a beautifully kept garden.',
      'Inside are spacious lounges, a fitted kitchen and bright, furnished bedrooms. Outside, a covered barbecue and dining area overlooks the pool, with a garden swing and space for children to play.',
    ],
    highlights: ['Fully furnished', 'Swimming pool', 'Beautiful garden', 'Outdoor barbecue area'],
    amenities: ['Furnished', 'Swimming pool', 'Garden', 'Parking', 'Air conditioning'],
    gallery: photos('MGR-0001', 12),
  },
  {
    ref: 'MGR-0002', slug: 'five-bedroom-all-ensuite-house-mbezi-beach',
    title: '5-Bedroom All En-Suite House', category: 'Residential', tx: 'sale',
    region: 'Dar es Salaam', city: 'Dar es Salaam', area: 'Mbezi Beach',
    price: 650000000, currency: 'TZS', priceDisplay: 'exact', negotiable: true,
    beds: 5, baths: 5, size: null, land: 800, floors: '2 storeys',
    status: 'Available', featured: true, isNew: true, added: '2026-11-18',
    short: 'Five-bedroom house, every bedroom en-suite, on an 800 m² plot with clean title deed.',
    description: [
      'A five-bedroom house for sale in Mbezi Beach, with every bedroom en-suite. The house stands on an 800 m² plot with a lawned garden and a paved driveway with parking.',
      'The property comes with a clean title deed. The price is negotiable.',
    ],
    highlights: ['All bedrooms en-suite', '800 m² plot', 'Clean title deed', 'Price negotiable'],
    amenities: ['Parking', 'Garden', 'Title deed'],
    gallery: photos('MGR-0002', 5),
  },
  {
    ref: 'MGR-0003', slug: 'epic-99-apartments-oyster-bay',
    title: 'Epic 99 — Sea-View Apartments', category: 'Apartments', tx: 'sale',
    region: 'Dar es Salaam', city: 'Dar es Salaam', area: 'Oyster Bay',
    price: 68524, currency: 'USD', priceDisplay: 'from', negotiable: false,
    beds: 3, baths: null, size: 41, land: null, floors: '25 floors',
    bedsLabel: 'Studio – 3 beds', sizeText: '41 – 169 m²',
    status: 'Available', featured: true, isNew: true, added: '2026-11-17',
    short: 'New tower of studios, 2- and 3-bedroom apartments with sea and city views, rooftop pool and gym.',
    description: [
      'Epic 99 is a new residential tower in Oyster Bay, between Kilimani Road, Tunisia Road and Kinondoni Road, in an area surrounded by embassies. Apartments offer sea and city views.',
      'Unit types include studios (41–45 m²), two-bedroom apartments (132 m²) and three-bedroom apartments (164–169 m²) from the 4th to the 24th floor, plus penthouse levels. Residents enjoy a swimming pool with ocean views, a fitness and recreation centre, lifts and underground parking.',
      'Listed prices start from USD 68,524 for a studio on the 4th floor and rise by floor and unit type. Instalment payment plans are available. Ask us for the full price list and availability.',
    ],
    highlights: ['Sea and city views', 'Studios, 2- and 3-bedroom units', 'Pool with ocean views', 'Instalment payment plans'],
    amenities: ['Swimming pool', 'Gym', 'Elevator', 'Parking', 'Balcony', 'Security'],
    imageNote: 'Images are artist’s impressions supplied by the developer.',
    gallery: photos('MGR-0003', 8),
  },
  {
    ref: 'MGR-0004', slug: 'amber-coast-residences-masaki',
    title: 'Amber Coast Residences', category: 'Apartments', tx: 'sale',
    region: 'Dar es Salaam', city: 'Dar es Salaam', area: 'Masaki',
    price: null, currency: 'USD', priceDisplay: 'request', negotiable: false,
    beds: 3, baths: null, size: 131, land: null, floors: 'Residential tower with penthouse floor',
    bedsLabel: '3-bed & penthouses', sizeText: '131 – 230 m²',
    status: 'Available', featured: true, isNew: true, added: '2026-11-17',
    short: 'Modern coastal residences in Masaki with sea or city views, from 131 m² to 230 m² penthouses.',
    description: [
      'Amber Coast Residences is a new residential building in Masaki offering modern coastal living, with units facing either the sea or the city.',
      'Each typical floor has six apartments of 131 m², 143 m² and 158 m² (the 158 m² Type A is a three-bedroom layout with two balconies), and the penthouse floor has four larger units of 207–230 m². The building has two lifts, two basement parking levels and a residents’ gym.',
      'Contact us for pricing, floor plans and current availability.',
    ],
    highlights: ['Sea-view and city-view units', 'Penthouses up to 230 m²', 'Two basement parking levels', 'Residents’ gym'],
    amenities: ['Elevator', 'Parking', 'Gym', 'Balcony', 'Security'],
    imageNote: 'Images are artist’s impressions supplied by the developer.',
    gallery: photos('MGR-0004', 11),
  },
  {
    ref: 'MGR-0005', slug: 'plot-for-sale-mbezi-beach-africana',
    title: '1,030 m² Plot at Mbezi Beach Africana', category: 'Land', tx: 'sale',
    region: 'Dar es Salaam', city: 'Dar es Salaam', area: 'Mbezi Beach (Africana)',
    price: 500000000, currency: 'TZS', priceDisplay: 'exact', negotiable: false,
    beds: null, baths: null, size: null, land: 1030, floors: null,
    status: 'Available', featured: true, isNew: true, added: '2026-11-17',
    short: '1,030 m² plot in the Africana area of Mbezi Beach.',
    description: [
      'A 1,030 m² plot for sale in the Africana area of Mbezi Beach, a popular residential neighbourhood.',
      'The plot currently has existing single-storey structures and mature trees, and is reached by an access road. Contact us to arrange a site visit.',
    ],
    highlights: ['1,030 m² plot', 'Africana, Mbezi Beach', 'Road access'],
    amenities: ['Access road'],
    gallery: photos('MGR-0005', 5),
  },
  {
    ref: 'MGR-0006', slug: 'industrial-plot-6-4-acres-kisemvule',
    title: '6.4-Acre Industrial Plot', category: 'Land', tx: 'sale',
    region: 'Pwani', city: 'Mkuranga', area: 'Kisemvule',
    price: 3300000000, currency: 'TZS', priceDisplay: 'exact', negotiable: true,
    beds: null, baths: null, size: null, land: 25525, floors: null,
    status: 'Available', featured: true, isNew: true, added: '2026-11-17',
    short: '25,525 m² industrial plot about 100 m from the main road, near Kingpins industry. Title deed.',
    description: [
      'A 6.4-acre (25,525 m²) industrial plot for sale at Kisemvule, only about 100 metres from the main road and close to the Kingpins industry.',
      'The plot is held under a title deed. The price is negotiable. Contact us to schedule a visit.',
    ],
    highlights: ['6.4 acres (25,525 m²)', '≈100 m from the main road', 'Near Kingpins industry', 'Title deed'],
    amenities: ['Access road', 'Title deed'],
    gallery: photos('MGR-0006', 8),
  },
  {
    ref: 'MGR-0007', slug: 'godown-for-rent-mandera-road-tabata',
    title: '1,300 m² Godown for Rent', category: 'Industrial Properties', tx: 'rent',
    region: 'Dar es Salaam', city: 'Dar es Salaam', area: 'Tabata (Mandera Road)',
    price: 7800, currency: 'USD', rentTerm: 'month', priceDisplay: 'exact', negotiable: false,
    unitRate: 'USD 6 per m² per month',
    beds: null, baths: null, size: 1300, land: null, floors: 'High-roof warehouse',
    status: 'Available', featured: true, isNew: true, added: '2026-11-17',
    short: '1,300 m² godown on Mandera Road, Tabata, at USD 6 per m² per month.',
    description: [
      'A 1,300 m² godown (warehouse) for rent on Mandera Road, Tabata. The high-roof steel structure has wide open floor space with truck access and an internal two-level office block.',
      'Rent is USD 6 per m² per month (USD 7,800 per month for the full 1,300 m²). The property has a washroom, parking space and security.',
    ],
    highlights: ['1,300 m² floor area', 'USD 6 per m² per month', 'Truck access', 'Internal office block'],
    amenities: ['Parking', 'Security', 'Washroom', 'Storage'],
    gallery: photos('MGR-0007', 6),
  },
  {
    ref: 'MGR-0008', slug: 'house-and-plot-for-sale-magomeni-makuti',
    title: 'House & Plot for Sale, Magomeni Makuti', category: 'Land', tx: 'sale',
    region: 'Dar es Salaam', city: 'Dar es Salaam', area: 'Magomeni Makuti',
    price: 400000000, currency: 'TZS', priceDisplay: 'exact', negotiable: false,
    beds: null, baths: null, size: null, land: 271, floors: null,
    status: 'Available', featured: true, isNew: true, added: '2026-11-17',
    short: '271 m² plot with house on Fundikira Street, facing a paved road. Ideal for investment. Title deed.',
    description: [
      'A house and 271 m² plot for sale on Fundikira Street, Magomeni Makuti. It is the third property from the main road and faces the paved street.',
      'The location suits many kinds of investment, such as apartments, a hotel, shops or a family home. The property is held under a title deed.',
    ],
    highlights: ['271 m² plot with house', 'Faces a paved street', 'Suits apartments, hotel or shops', 'Title deed'],
    amenities: ['Access road', 'Title deed', 'Water supply'],
    gallery: photos('MGR-0008', 6),
  },

  /* ===================== SAMPLE LISTINGS ===================== */
  {
    ref: 'SMP-001', slug: 'sample-family-villa-with-pool-oyster-bay', sample: true,
    title: 'Family Villa with Pool', category: 'Luxury Properties', tx: 'sale',
    region: 'Dar es Salaam', city: 'Dar es Salaam', area: 'Oyster Bay',
    price: 1150000, currency: 'USD', priceDisplay: 'exact', negotiable: true,
    beds: 5, baths: 5, size: 480, land: 1400, floors: '2 storeys',
    status: 'Available', featured: false, added: '2026-11-05',
    short: 'Five-bedroom villa with landscaped garden, pool and staff quarters.',
    description: [
      'A spacious two-storey family villa on a generous plot, with open-plan living and dining areas opening onto a landscaped garden and swimming pool.',
      'Four en-suite bedrooms upstairs, a guest bedroom downstairs, staff quarters and covered parking.',
    ],
    highlights: ['Private swimming pool', 'Landscaped garden', 'Staff quarters'],
    amenities: ['Parking', 'Swimming pool', 'Garden', 'Security', 'Air conditioning', 'Backup power', 'Water supply'],
    gallery: ['villa', 'living', 'kitchen', 'bedroom', 'bath'],
  },
  {
    ref: 'SMP-002', slug: 'sample-two-bedroom-apartment-mikocheni', sample: true,
    title: 'Two-Bedroom Apartment', category: 'Apartments', tx: 'rent',
    region: 'Dar es Salaam', city: 'Dar es Salaam', area: 'Mikocheni B',
    price: 1500000, currency: 'TZS', rentTerm: 'month', priceDisplay: 'exact', negotiable: false,
    beds: 2, baths: 2, size: 105, land: null, floors: '2nd floor',
    status: 'Available', featured: false, added: '2026-11-08',
    short: 'Unfurnished apartment with balcony, parking and backup power.',
    description: ['A well-kept unfurnished two-bedroom apartment with a balcony, open kitchen and one en-suite bedroom. Includes parking, backup power for common areas and security.'],
    highlights: ['Balcony', 'En-suite bedroom', 'Backup power'],
    amenities: ['Parking', 'Security', 'Balcony', 'Water supply', 'Backup power'],
    gallery: ['tower2', 'living', 'bedroom'],
  },
  {
    ref: 'SMP-003', slug: 'sample-office-floor-msasani', sample: true,
    title: 'Open-Plan Office Floor', category: 'Offices', tx: 'rent',
    region: 'Dar es Salaam', city: 'Dar es Salaam', area: 'Msasani (Old Bagamoyo Rd)',
    price: 5600, currency: 'USD', rentTerm: 'month', priceDisplay: 'exact', negotiable: true,
    beds: null, baths: 4, size: 400, land: null, floors: '3rd floor',
    status: 'Available', featured: false, added: '2026-11-03',
    short: 'Full office floor with meeting rooms, reception and parking.',
    description: ['A full open-plan office floor with reception, two meeting rooms, kitchenette and washrooms, in a building with lift access, backup power and allocated parking.'],
    highlights: ['Full floor', 'Two meeting rooms', 'Allocated parking'],
    amenities: ['Parking', 'Security', 'Air conditioning', 'Elevator', 'Internet', 'Backup power'],
    gallery: ['office', 'officeInt', 'officeInt2'],
  },
  {
    ref: 'SMP-004', slug: 'sample-retail-shop-kariakoo', sample: true,
    title: 'Street-Front Retail Shop', category: 'Retail Spaces', tx: 'rent',
    region: 'Dar es Salaam', city: 'Dar es Salaam', area: 'Kariakoo',
    price: 2500000, currency: 'TZS', rentTerm: 'month', priceDisplay: 'exact', negotiable: true,
    beds: null, baths: 1, size: 60, land: null, floors: 'Ground floor',
    status: 'Available', featured: false, added: '2026-10-30',
    short: 'Ground-floor shop with street frontage in a busy trading area.',
    description: ['A ground-floor retail unit with glazed street frontage in a busy commercial area, with a rear storage room and washroom.'],
    highlights: ['Street frontage', 'Rear storage', 'Busy trading area'],
    amenities: ['Security', 'Storage', 'Water supply'],
    gallery: ['shop', 'shopInt'],
  },
  {
    ref: 'SMP-005', slug: 'sample-beach-holiday-home-jambiani-zanzibar', sample: true,
    title: 'Beach Holiday Home', category: 'Holiday Homes', tx: 'sale',
    region: 'Zanzibar', city: 'Jambiani', area: 'Jambiani Beach',
    price: 245000, currency: 'USD', priceDisplay: 'exact', negotiable: false,
    beds: 3, baths: 3, size: 190, land: 600, floors: 'Single storey',
    status: 'Reserved', featured: false, added: '2026-10-24',
    short: 'Three-bedroom holiday home a short walk from the beach.',
    description: ['A relaxed three-bedroom holiday home with covered veranda, plunge pool and tropical garden, a short walk from the beach.'],
    highlights: ['Plunge pool', 'Covered veranda', 'Near the beach'],
    amenities: ['Parking', 'Swimming pool', 'Garden', 'Air conditioning', 'Furnished', 'Water supply'],
    gallery: ['beach', 'living', 'bedroom', 'bath'],
  },
  {
    ref: 'SMP-006', slug: 'sample-commercial-building-dodoma', sample: true,
    title: 'Mixed-Use Commercial Building', category: 'Commercial', tx: 'sale',
    region: 'Dodoma', city: 'Dodoma', area: 'Area D',
    price: 2400000000, currency: 'TZS', priceDisplay: 'exact', negotiable: true,
    beds: null, baths: 8, size: 1100, land: 900, floors: '4 storeys',
    status: 'Available', featured: false, added: '2026-10-15',
    short: 'Four-storey building with ground-floor retail and offices above.',
    description: ['A four-storey mixed-use building with ground-floor retail units and three floors of office space, with parking, lift and backup power.'],
    highlights: ['Ground-floor retail', 'Three office floors', 'On-site parking'],
    amenities: ['Parking', 'Security', 'Elevator', 'Backup power', 'Water supply'],
    gallery: ['office2', 'officeInt'],
  },
]

export const AMENITIES = [...new Set(PROPERTIES.flatMap((p) => p.amenities))].sort()

// Actual listings first, then featured, then newest
export const listingOrder = (a, b) => (!!a.sample - !!b.sample) || (b.featured - a.featured) || b.added.localeCompare(a.added)

export const publicProperties = () => PROPERTIES.filter((p) => PUBLIC_STATUSES.includes(p.status))
export const findProperty = (slug) => PROPERTIES.find((p) => p.slug === slug)
export const byRef = (ref) => PROPERTIES.find((p) => p.ref === ref)

export function similarProperties(p, n = 3) {
  return publicProperties()
    .filter((x) => x.ref !== p.ref)
    .map((x) => ({
      x,
      score: (x.category === p.category ? 3 : 0) + (x.tx === p.tx ? 2 : 0) + (x.region === p.region ? 1 : 0) + (!x.sample ? 1.5 : 0),
    }))
    .sort((a, b) => b.score - a.score)
    .slice(0, n)
    .map((s) => s.x)
}
