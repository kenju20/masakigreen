// FAQ content. Answers avoid stating fees, timelines or legal rules that have not been confirmed.
export const FAQ_GROUPS = [
  {
    group: 'Working with us',
    items: [
      { q: 'What services does Masaki Green Realty provide?', a: 'We provide property sales, property rentals, property management, and real estate investment and advisory services, covering residential, commercial and investment property.' },
      { q: 'Which areas do you cover?', a: 'We are based at 190 Kimweri Road, Masaki, Dar es Salaam, and serve clients and property opportunities across Tanzania.' },
      { q: 'Do you only deal with luxury properties?', a: 'No. We serve both the general and the premium real estate market, from apartments and family homes to commercial premises, land and investment property.' },
      { q: 'How do I contact you?', a: 'You can call or WhatsApp us on +255 657 633 698, email info@masakigreenrealty.co.tz, use the enquiry form on any property page, or visit our office in Masaki.' },
    ],
  },
  {
    group: 'Buying and renting',
    items: [
      { q: 'How do I arrange a property viewing?', a: 'Use the enquiry form on the property page, or contact us by phone or WhatsApp quoting the property reference number (for example MGR-0001). We will arrange a suitable time.' },
      { q: 'What does the reference number on a listing mean?', a: 'Every property has a unique reference number. Quoting it when you contact us helps us identify the exact property you are asking about.' },
      { q: 'Why are some prices in TZS and others in USD?', a: 'Each property is shown in the currency its price was set in. We do not automatically convert prices, because exchange rates change and converted figures could be misleading.' },
      { q: 'What does “Reserved” mean?', a: 'A reserved property has an offer or arrangement in progress. You can still enquire, and we will let you know if it becomes available again.' },
      { q: 'What does “Price on request” mean?', a: 'For some properties the price is shared directly with interested parties. Send an enquiry and we will provide the details.' },
    ],
  },
  {
    group: 'Property owners',
    items: [
      { q: 'Can you help me sell or let my property?', a: 'Yes. Contact us with details of your property and we will discuss how we can help you reach prospective buyers or tenants.' },
      { q: 'Can I list my property directly on the website?', a: 'Properties on our website are listed and managed by Masaki Green Realty. Please contact us and our team will discuss your property with you.' },
      { q: 'What does property management include?', a: 'Our property management service helps owners oversee their investment and keep their property maintained. Contact us to discuss what your property needs.' },
    ],
  },
  {
    group: 'Using this website',
    items: [
      { q: 'How do saved properties work?', a: 'Tap the heart on any property to save it. Saved properties are kept in your browser on this device, so you do not need an account.' },
      { q: 'How does property comparison work?', a: 'Select “Compare” on up to four properties, then open the comparison page to view them side by side. Prices are shown in each property’s own currency and are never converted.' },
    ],
  },
]
