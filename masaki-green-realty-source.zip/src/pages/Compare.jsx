import { Link } from 'react-router-dom'
import Icon from '../components/Icon'
import PropertyImage from '../components/PropertyImage'
import { PageHero, usePageTitle } from '../components/Layout'
import { Empty, PropertyCard } from '../components/Widgets'
import { byRef } from '../data/properties'
import { bedsText, formatPrice, fullLocation, rentSuffix, txLabel } from '../lib/format'
import { useStore } from '../lib/store'

export default function Compare() {
  usePageTitle('Compare Properties')
  const { compare, toggleCompare, clearCompare } = useStore()
  const items = compare.map(byRef).filter(Boolean)
  const currencies = [...new Set(items.map((p) => p.currency))]
  const txs = [...new Set(items.map((p) => p.tx))]
  const amenities = [...new Set(items.flatMap((p) => p.amenities))].sort()
  const dash = <span className="na">—</span>

  const rows = [
    ['Reference', (p) => p.ref],
    ['Price', (p) => <><strong className="cmp-price">{formatPrice(p)}</strong>{rentSuffix(p) && <small>{rentSuffix(p)}</small>}</>],
    ['Currency', (p) => <span className={`cur-tag cur-${p.currency.toLowerCase()}`}>{p.currency}</span>],
    ['Transaction', (p) => txLabel(p.tx)],
    ['Property type', (p) => p.category],
    ['Location', (p) => fullLocation(p)],
    ['Bedrooms', (p) => (bedsText(p) ? (p.bedsLabel || p.beds) : dash)],
    ['Bathrooms', (p) => p.baths ?? dash],
    ['Floor area', (p) => (p.sizeText || (p.size ? `${p.size.toLocaleString()} m²` : dash))],
    ['Land size', (p) => (p.land ? `${p.land.toLocaleString()} m²` : dash)],
    ['Availability', (p) => <span className={`status-line s-${p.status.toLowerCase()}`}><span className="sdot" /> {p.status}</span>],
  ]

  return (
    <>
      <PageHero eyebrow="Compare" title="Compare properties" crumbs={[['Home', '/'], ['Properties', '/properties'], ['Compare']]}
        text="View up to four properties side by side. Each price is shown in its own listed currency." />
      <section className="section-tight">
        <div className="container">
          {items.length === 0 ? (
            <Empty icon="compare" title="No properties selected" text="Select “Compare” on any property card or property page to add it here.">
              <Link className="btn btn-green" to="/properties">Browse properties</Link>
            </Empty>
          ) : (
            <>
              <div className="cmp-toolbar">
                <p><strong>{items.length}</strong> of 4 properties selected</p>
                <div className="btn-row">
                  <Link to="/properties" className="btn btn-outline btn-sm">Add more</Link>
                  <button className="btn btn-outline btn-sm" onClick={clearCompare}>Clear all</button>
                </div>
              </div>
              {currencies.length > 1 && (
                <div className="notice-inline warn"><Icon name="info" size={18} />
                  <span><strong>Different currencies.</strong> These properties are priced in {currencies.join(' and ')}. Prices are shown exactly as listed and are <strong>not converted</strong>, so they should not be compared as equal amounts.</span>
                </div>
              )}
              {txs.length > 1 && (
                <div className="notice-inline"><Icon name="info" size={18} /><span>This comparison includes both sale prices and rental amounts.</span></div>
              )}
              {items.length === 1 && <p className="notice-inline"><Icon name="info" size={18} /> Add at least one more property to compare.</p>}
              <div className="cmp-scroll" tabIndex={0} aria-label="Comparison table, scroll horizontally on small screens">
                <table className="cmp" style={{ '--cols': items.length }}>
                  <thead>
                    <tr>
                      <th scope="col" className="cmp-label"><span className="sr-only">Feature</span></th>
                      {items.map((p) => (
                        <th scope="col" key={p.ref}>
                          <div className="cmp-head">
                            <button className="cmp-remove" onClick={() => toggleCompare(p.ref)} aria-label={`Remove ${p.title}`}><Icon name="x" size={16} /></button>
                            <Link to={`/property/${p.slug}`} className="cmp-img"><PropertyImage img={p.gallery[0]} alt={p.title} label={false} /></Link>
                            <Link to={`/property/${p.slug}`} className="cmp-title">{p.title}</Link>
                          </div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map(([label, fn]) => (
                      <tr key={label}><th scope="row" className="cmp-label">{label}</th>{items.map((p) => <td key={p.ref}>{fn(p)}</td>)}</tr>
                    ))}
                    <tr className="cmp-section"><th scope="row" className="cmp-label" colSpan={items.length + 1}>Amenities</th></tr>
                    {amenities.map((a) => (
                      <tr key={a}><th scope="row" className="cmp-label">{a}</th>
                        {items.map((p) => <td key={p.ref}>{p.amenities.includes(a) ? <Icon name="check" size={18} className="yes" title="Yes" /> : <span className="na" aria-label="No">—</span>}</td>)}
                      </tr>
                    ))}
                    <tr><th scope="row" className="cmp-label"><span className="sr-only">Actions</span></th>
                      {items.map((p) => <td key={p.ref}><Link to={`/property/${p.slug}`} className="btn btn-green btn-sm">View details</Link></td>)}
                    </tr>
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>
      </section>
    </>
  )
}

export function Saved() {
  usePageTitle('Saved Properties')
  const { saved, clearSaved } = useStore()
  const items = saved.map(byRef).filter(Boolean)
  return (
    <>
      <PageHero eyebrow="Saved" title="Saved properties" crumbs={[['Home', '/'], ['Saved']]}
        text="Properties you have saved are kept in this browser on this device. No account needed." />
      <section className="section-tight">
        <div className="container">
          {items.length === 0 ? (
            <Empty icon="heart" title="You have not saved any properties yet" text="Tap the heart on any property to keep it here for later.">
              <Link className="btn btn-green" to="/properties">Browse properties</Link>
            </Empty>
          ) : (
            <>
              <div className="cmp-toolbar">
                <p><strong>{items.length}</strong> saved {items.length === 1 ? 'property' : 'properties'}</p>
                <button className="btn btn-outline btn-sm" onClick={clearSaved}>Clear saved</button>
              </div>
              <div className="grid-3">{items.map((p) => <PropertyCard key={p.ref} p={p} />)}</div>
            </>
          )}
        </div>
      </section>
    </>
  )
}
