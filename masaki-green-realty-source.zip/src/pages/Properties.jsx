import { useEffect, useMemo, useRef, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import Icon from '../components/Icon'
import { PageHero, usePageTitle } from '../components/Layout'
import { Empty, PropertyCard } from '../components/Widgets'
import { AMENITIES, CATEGORIES, byRef, listingOrder, publicProperties } from '../data/properties'
import { useStore } from '../lib/store'

const PER_PAGE = 6
const SORTS = [
  ['featured', 'Featured first'],
  ['newest', 'Newest first'],
  ['price-asc', 'Price: low to high'],
  ['price-desc', 'Price: high to low'],
  ['size-desc', 'Size: largest first'],
]
const effSize = (p) => p.size ?? p.land ?? 0

export default function Properties() {
  usePageTitle('Properties for Sale and Rent', 'Browse residential, commercial, land and investment properties for sale and rent across Tanzania.')
  const [sp, setSp] = useSearchParams()
  const [panel, setPanel] = useState(false)
  const [loading, setLoading] = useState(false)
  const topRef = useRef(null)
  const { recent } = useStore()
  const all = publicProperties()

  const get = (k) => sp.get(k) || ''
  const f = {
    tx: get('tx'), cat: get('cat'), region: get('region'), city: get('city'), area: get('area'),
    cur: get('cur'), min: get('min'), max: get('max'), beds: get('beds'), baths: get('baths'),
    smin: get('smin'), smax: get('smax'), status: get('status'), q: get('q'),
    am: get('am') ? get('am').split('|') : [], sort: get('sort') || 'featured', page: Math.max(1, +get('page') || 1),
  }

  function update(changes, keepPage = false) {
    const next = new URLSearchParams(sp)
    Object.entries(changes).forEach(([k, v]) => {
      if (v === '' || v == null || (Array.isArray(v) && !v.length)) next.delete(k)
      else next.set(k, Array.isArray(v) ? v.join('|') : String(v))
    })
    if (!keepPage) next.delete('page')
    setSp(next, { replace: true })
  }
  const reset = () => setSp(new URLSearchParams(), { replace: true })

  // brief loading feedback when criteria change
  const key = sp.toString()
  useEffect(() => {
    setLoading(true)
    const t = setTimeout(() => setLoading(false), 220)
    return () => clearTimeout(t)
  }, [key])

  // location hierarchy options
  const regions = [...new Set(all.map((p) => p.region))].sort()
  const cities = [...new Set(all.filter((p) => !f.region || p.region === f.region).map((p) => p.city))].sort()
  const areas = [...new Set(all.filter((p) => (!f.region || p.region === f.region) && (!f.city || p.city === f.city)).map((p) => p.area))].sort()

  const results = useMemo(() => {
    const q = f.q.toLowerCase().trim()
    const min = f.min ? +f.min : null
    const max = f.max ? +f.max : null
    let r = all.filter((p) => {
      if (f.tx && p.tx !== f.tx) return false
      if (f.cat && p.category !== f.cat) return false
      if (f.region && p.region !== f.region) return false
      if (f.city && p.city !== f.city) return false
      if (f.area && p.area !== f.area) return false
      if (f.cur && p.currency !== f.cur) return false
      // Price limits only apply within a selected currency (no conversion)
      if (f.cur && (min != null || max != null)) {
        if (p.priceDisplay === 'request' || p.price == null) return false
        if (min != null && p.price < min) return false
        if (max != null && p.price > max) return false
      }
      if (f.beds && (p.beds == null || p.beds < +f.beds)) return false
      if (f.baths && (p.baths == null || p.baths < +f.baths)) return false
      if (f.smin && effSize(p) < +f.smin) return false
      if (f.smax && effSize(p) > +f.smax) return false
      if (f.status && p.status !== f.status) return false
      if (f.am.length && !f.am.every((a) => p.amenities.includes(a))) return false
      if (q) {
        const hay = [p.title, p.ref, p.category, p.area, p.city, p.region, p.short, ...p.amenities, ...p.highlights].join(' ').toLowerCase()
        if (!q.split(/\s+/).every((w) => hay.includes(w))) return false
      }
      return true
    })
    const curOrder = (p) => (p.currency === 'TZS' ? 0 : 1)
    const priced = (p) => p.priceDisplay !== 'request' && p.price != null
    const sorts = {
      featured: listingOrder,
      newest: (a, b) => b.added.localeCompare(a.added) || (!!a.sample - !!b.sample),
      // price sorting is done within each currency; price-on-request goes last
      'price-asc': (a, b) => (priced(b) - priced(a)) || (curOrder(a) - curOrder(b)) || (a.price - b.price),
      'price-desc': (a, b) => (priced(b) - priced(a)) || (curOrder(a) - curOrder(b)) || (b.price - a.price),
      'size-desc': (a, b) => effSize(b) - effSize(a),
    }
    return [...r].sort(sorts[f.sort] || sorts.featured)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key])

  const pages = Math.max(1, Math.ceil(results.length / PER_PAGE))
  const page = Math.min(f.page, pages)
  const shown = results.slice((page - 1) * PER_PAGE, page * PER_PAGE)
  const mixedPriceSort = f.sort.startsWith('price') && !f.cur && new Set(results.map((p) => p.currency)).size > 1

  const activeCount = ['tx', 'cat', 'region', 'city', 'area', 'cur', 'min', 'max', 'beds', 'baths', 'smin', 'smax', 'status', 'q'].filter((k) => f[k]).length + f.am.length
  const goPage = (n) => { update({ page: n }, true); topRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }) }
  const recentProps = recent.map(byRef).filter((p) => p && p.status !== 'Sold')

  const filters = (
    <div className="filters-inner">
      <div className="filters-head">
        <h2><Icon name="filter" size={18} /> Filters {activeCount > 0 && <span className="pill">{activeCount}</span>}</h2>
        <button className="link-btn" onClick={reset} disabled={!activeCount}>Clear all</button>
      </div>

      <div className="fgroup">
        <span className="flabel">Looking to</span>
        <div className="seg seg-full">
          {[['', 'All'], ['sale', 'Buy'], ['rent', 'Rent']].map(([v, l]) => (
            <button type="button" key={l} className={f.tx === v ? 'on' : ''} aria-pressed={f.tx === v} onClick={() => update({ tx: v })}>{l}</button>
          ))}
        </div>
      </div>

      <div className="fgroup">
        <label className="flabel" htmlFor="f-q">Keyword or reference</label>
        <input id="f-q" placeholder="e.g. pool, MGR-0002" defaultValue={f.q} key={`q${f.q}`}
          onKeyDown={(e) => e.key === 'Enter' && update({ q: e.currentTarget.value })} onBlur={(e) => e.currentTarget.value !== f.q && update({ q: e.currentTarget.value })} />
      </div>

      <div className="fgroup">
        <label className="flabel" htmlFor="f-cat">Property type</label>
        <select id="f-cat" value={f.cat} onChange={(e) => update({ cat: e.target.value })}>
          <option value="">All types</option>
          {CATEGORIES.map((c) => <option key={c.slug}>{c.name}</option>)}
        </select>
      </div>

      <div className="fgroup">
        <span className="flabel">Location</span>
        <select aria-label="Region" value={f.region} onChange={(e) => update({ region: e.target.value, city: '', area: '' })}>
          <option value="">All regions</option>{regions.map((r) => <option key={r}>{r}</option>)}
        </select>
        <select aria-label="City" value={f.city} onChange={(e) => update({ city: e.target.value, area: '' })}>
          <option value="">All cities</option>{cities.map((r) => <option key={r}>{r}</option>)}
        </select>
        <select aria-label="Neighbourhood" value={f.area} onChange={(e) => update({ area: e.target.value })}>
          <option value="">All neighbourhoods</option>{areas.map((r) => <option key={r}>{r}</option>)}
        </select>
      </div>

      <div className="fgroup">
        <label className="flabel" htmlFor="f-cur">Currency</label>
        <select id="f-cur" value={f.cur} onChange={(e) => update({ cur: e.target.value, ...(e.target.value ? {} : { min: '', max: '' }) })}>
          <option value="">TZS and USD</option><option value="TZS">TZS only</option><option value="USD">USD only</option>
        </select>
        <div className="frow">
          <input type="number" min="0" inputMode="numeric" aria-label="Minimum price" placeholder={f.cur ? `Min ${f.cur}` : 'Min price'} disabled={!f.cur}
            defaultValue={f.min} key={`min${f.min}${f.cur}`} onBlur={(e) => e.currentTarget.value !== f.min && update({ min: e.currentTarget.value })} onKeyDown={(e) => e.key === 'Enter' && update({ min: e.currentTarget.value })} />
          <input type="number" min="0" inputMode="numeric" aria-label="Maximum price" placeholder={f.cur ? `Max ${f.cur}` : 'Max price'} disabled={!f.cur}
            defaultValue={f.max} key={`max${f.max}${f.cur}`} onBlur={(e) => e.currentTarget.value !== f.max && update({ max: e.currentTarget.value })} onKeyDown={(e) => e.key === 'Enter' && update({ max: e.currentTarget.value })} />
        </div>
        <p className="fhint">{f.cur ? `Prices in ${f.cur}, as listed. Rentals use the listed rent.` : 'Choose a currency to set a price range. Prices are never converted.'}</p>
      </div>

      <div className="fgroup frow">
        <div>
          <label className="flabel" htmlFor="f-beds">Bedrooms</label>
          <select id="f-beds" value={f.beds} onChange={(e) => update({ beds: e.target.value })}>
            <option value="">Any</option>{[1, 2, 3, 4, 5].map((n) => <option key={n} value={n}>{n}+</option>)}
          </select>
        </div>
        <div>
          <label className="flabel" htmlFor="f-baths">Bathrooms</label>
          <select id="f-baths" value={f.baths} onChange={(e) => update({ baths: e.target.value })}>
            <option value="">Any</option>{[1, 2, 3, 4].map((n) => <option key={n} value={n}>{n}+</option>)}
          </select>
        </div>
      </div>

      <div className="fgroup">
        <span className="flabel">Size (m², building or plot)</span>
        <div className="frow">
          <input type="number" min="0" aria-label="Minimum size in square metres" placeholder="Min m²" defaultValue={f.smin} key={`smin${f.smin}`} onBlur={(e) => e.currentTarget.value !== f.smin && update({ smin: e.currentTarget.value })} onKeyDown={(e) => e.key === 'Enter' && update({ smin: e.currentTarget.value })} />
          <input type="number" min="0" aria-label="Maximum size in square metres" placeholder="Max m²" defaultValue={f.smax} key={`smax${f.smax}`} onBlur={(e) => e.currentTarget.value !== f.smax && update({ smax: e.currentTarget.value })} onKeyDown={(e) => e.key === 'Enter' && update({ smax: e.currentTarget.value })} />
        </div>
      </div>

      <div className="fgroup">
        <label className="flabel" htmlFor="f-status">Availability</label>
        <select id="f-status" value={f.status} onChange={(e) => update({ status: e.target.value })}>
          <option value="">Available and reserved</option><option>Available</option><option>Reserved</option>
        </select>
      </div>

      <div className="fgroup">
        <span className="flabel">Features and amenities</span>
        <div className="amen-checks">
          {AMENITIES.map((a) => (
            <label key={a} className={`amen-check ${f.am.includes(a) ? 'on' : ''}`}>
              <input type="checkbox" checked={f.am.includes(a)} onChange={() => update({ am: f.am.includes(a) ? f.am.filter((x) => x !== a) : [...f.am, a] })} />
              {a}
            </label>
          ))}
        </div>
      </div>
    </div>
  )

  return (
    <>
      <PageHero eyebrow="Properties" title="Properties for sale and rent" crumbs={[['Home', '/'], ['Properties']]}
        text="Search residential, commercial, land and investment properties across Tanzania." />
      <section className="section-tight" ref={topRef}>
        <div className="container listing-layout">
          <aside className={`filters ${panel ? 'open' : ''}`} aria-label="Property filters">
            <div className="filters-mobile-bar">
              <strong>Filters</strong>
              <button className="icon-btn" onClick={() => setPanel(false)} aria-label="Close filters"><Icon name="x" /></button>
            </div>
            {filters}
            <div className="filters-mobile-foot">
              <button className="btn btn-outline" onClick={reset}>Clear</button>
              <button className="btn btn-green" onClick={() => setPanel(false)}>Show {results.length} {results.length === 1 ? 'property' : 'properties'}</button>
            </div>
          </aside>
          {panel && <div className="nav-scrim" onClick={() => setPanel(false)} />}

          <div className="listing-main">
            <div className="toolbar">
              <button className="btn btn-outline btn-sm filters-open" onClick={() => setPanel(true)}>
                <Icon name="filter" size={16} /> Filters {activeCount > 0 && <span className="pill">{activeCount}</span>}
              </button>
              <p className="result-count" aria-live="polite">
                {results.length ? <>Showing <strong>{(page - 1) * PER_PAGE + 1}–{Math.min(page * PER_PAGE, results.length)}</strong> of <strong>{results.length}</strong> {results.length === 1 ? 'property' : 'properties'}</> : 'No properties found'}
              </p>
              <label className="sort">
                <Icon name="sort" size={16} /><span className="sr-only">Sort by</span>
                <select value={f.sort} onChange={(e) => update({ sort: e.target.value })}>{SORTS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select>
              </label>
            </div>

            {activeCount > 0 && (
              <div className="active-filters">
                {f.tx && <button onClick={() => update({ tx: '' })}>{f.tx === 'sale' ? 'For sale' : 'For rent'} <Icon name="x" size={13} /></button>}
                {f.cat && <button onClick={() => update({ cat: '' })}>{f.cat} <Icon name="x" size={13} /></button>}
                {f.region && <button onClick={() => update({ region: '', city: '', area: '' })}>{f.region} <Icon name="x" size={13} /></button>}
                {f.city && <button onClick={() => update({ city: '', area: '' })}>{f.city} <Icon name="x" size={13} /></button>}
                {f.area && <button onClick={() => update({ area: '' })}>{f.area} <Icon name="x" size={13} /></button>}
                {f.cur && <button onClick={() => update({ cur: '', min: '', max: '' })}>{f.cur} <Icon name="x" size={13} /></button>}
                {f.min && <button onClick={() => update({ min: '' })}>Min {f.cur} {(+f.min).toLocaleString()} <Icon name="x" size={13} /></button>}
                {f.max && <button onClick={() => update({ max: '' })}>Max {f.cur} {(+f.max).toLocaleString()} <Icon name="x" size={13} /></button>}
                {f.beds && <button onClick={() => update({ beds: '' })}>{f.beds}+ beds <Icon name="x" size={13} /></button>}
                {f.baths && <button onClick={() => update({ baths: '' })}>{f.baths}+ baths <Icon name="x" size={13} /></button>}
                {f.smin && <button onClick={() => update({ smin: '' })}>≥ {f.smin} m² <Icon name="x" size={13} /></button>}
                {f.smax && <button onClick={() => update({ smax: '' })}>≤ {f.smax} m² <Icon name="x" size={13} /></button>}
                {f.status && <button onClick={() => update({ status: '' })}>{f.status} <Icon name="x" size={13} /></button>}
                {f.q && <button onClick={() => update({ q: '' })}>“{f.q}” <Icon name="x" size={13} /></button>}
                {f.am.map((a) => <button key={a} onClick={() => update({ am: f.am.filter((x) => x !== a) })}>{a} <Icon name="x" size={13} /></button>)}
                <button className="clear" onClick={reset}>Clear all</button>
              </div>
            )}

            {mixedPriceSort && (
              <p className="notice-inline"><Icon name="info" size={16} /> Sorted by price within each currency (TZS first, then USD). Prices are not converted between currencies.</p>
            )}

            {loading ? (
              <div className="grid-2 skeletons">{Array.from({ length: Math.min(4, results.length || 2) }, (_, i) => <div key={i} className="skeleton" />)}</div>
            ) : shown.length ? (
              <div className="grid-2">{shown.map((p) => <PropertyCard key={p.ref} p={p} />)}</div>
            ) : (
              <Empty title="No properties match your search" text="Try removing a filter or widening your price or size range. You can also tell us what you need and we will look for suitable options.">
                <div className="btn-row center">
                  <button className="btn btn-green" onClick={reset}>Clear all filters</button>
                  <Link className="btn btn-outline" to="/contact">Send us your requirements</Link>
                </div>
              </Empty>
            )}

            {pages > 1 && !loading && (
              <nav className="pagination" aria-label="Pagination">
                <button disabled={page === 1} onClick={() => goPage(page - 1)} aria-label="Previous page"><Icon name="left" size={18} /></button>
                {Array.from({ length: pages }, (_, i) => i + 1).map((n) => (
                  <button key={n} className={n === page ? 'on' : ''} aria-current={n === page ? 'page' : undefined} onClick={() => goPage(n)}>{n}</button>
                ))}
                <button disabled={page === pages} onClick={() => goPage(page + 1)} aria-label="Next page"><Icon name="right" size={18} /></button>
              </nav>
            )}
            <p className="sample-note"><Icon name="info" size={15} /> Listings marked “Sample listing” are demonstration content.</p>
          </div>
        </div>
      </section>

      {recentProps.length > 0 && (
        <section className="section-tight bg-soft">
          <div className="container">
            <h2 className="h-sm"><Icon name="clock" size={20} /> Recently viewed</h2>
            <div className="grid-4">{recentProps.slice(0, 4).map((p) => <PropertyCard key={p.ref} p={p} />)}</div>
          </div>
        </section>
      )}
    </>
  )
}
