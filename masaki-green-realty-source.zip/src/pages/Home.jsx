import { useMemo, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import Icon from '../components/Icon'
import PropertyImage from '../components/PropertyImage'
import { SectionHead, usePageTitle } from '../components/Layout'
import { PropertyCard } from '../components/Widgets'
import { COMPANY, SERVICES, waLink } from '../data/company'
import { CATEGORIES, listingOrder, publicProperties } from '../data/properties'
import { ARTICLES } from '../data/articles'
import { fmtDate } from '../lib/format'

function HeroSearch() {
  const nav = useNavigate()
  const props = publicProperties()
  const regions = [...new Set(props.map((p) => p.region))].sort()
  const [tx, setTx] = useState('')
  const [cat, setCat] = useState('')
  const [region, setRegion] = useState('')
  const [beds, setBeds] = useState('')
  const [q, setQ] = useState('')
  function go(e) {
    e.preventDefault()
    const s = new URLSearchParams()
    if (tx) s.set('tx', tx)
    if (cat) s.set('cat', cat)
    if (region) s.set('region', region)
    if (beds) s.set('beds', beds)
    if (q.trim()) s.set('q', q.trim())
    nav(`/properties${s.toString() ? `?${s}` : ''}`)
  }
  return (
    <form className="hero-search" onSubmit={go} role="search" aria-label="Property search">
      <div className="seg" role="radiogroup" aria-label="Transaction type">
        {[['', 'All'], ['sale', 'Buy'], ['rent', 'Rent']].map(([v, l]) => (
          <button type="button" key={l} role="radio" aria-checked={tx === v} className={tx === v ? 'on' : ''} onClick={() => setTx(v)}>{l}</button>
        ))}
      </div>
      <div className="hero-search-grid">
        <div className="field">
          <label htmlFor="hs-q">Keyword</label>
          <input id="hs-q" placeholder="Area, feature or reference" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <div className="field">
          <label htmlFor="hs-cat">Property type</label>
          <select id="hs-cat" value={cat} onChange={(e) => setCat(e.target.value)}>
            <option value="">All types</option>
            {CATEGORIES.map((c) => <option key={c.slug}>{c.name}</option>)}
          </select>
        </div>
        <div className="field">
          <label htmlFor="hs-reg">Location</label>
          <select id="hs-reg" value={region} onChange={(e) => setRegion(e.target.value)}>
            <option value="">All of Tanzania</option>
            {regions.map((r) => <option key={r}>{r}</option>)}
          </select>
        </div>
        <div className="field">
          <label htmlFor="hs-beds">Bedrooms</label>
          <select id="hs-beds" value={beds} onChange={(e) => setBeds(e.target.value)}>
            <option value="">Any</option>
            {[1, 2, 3, 4, 5].map((n) => <option key={n} value={n}>{n}+</option>)}
          </select>
        </div>
        <button className="btn btn-green hero-search-btn" type="submit"><Icon name="search" /> Search</button>
      </div>
    </form>
  )
}

export default function Home() {
  usePageTitle(null, 'Masaki Green Realty — property sales, rentals, management and investment advisory in Tanzania. Based in Masaki, Dar es Salaam.')
  const all = publicProperties()
  const featured = useMemo(() => all.filter((p) => p.featured).sort(listingOrder).slice(0, 8), [all])
  const more = useMemo(() => all.filter((p) => !p.featured).sort(listingOrder).slice(0, 4), [all])
  const counts = Object.fromEntries(CATEGORIES.map((c) => [c.name, all.filter((p) => p.category === c.name).length]))

  return (
    <>
      {/* HERO */}
      <section className="hero">
        <div className="hero-media"><PropertyImage img="mgr-0004-3" alt="" label={false} eager /></div>
        <div className="hero-shade" />
        <Link to="/property/amber-coast-residences-masaki" className="hero-caption">Amber Coast Residences, Masaki · artist’s impression</Link>
        <div className="container hero-in">
          <span className="eyebrow eyebrow-light">Buy · Sell · Invest</span>
          <h1>Your trusted property partner in Tanzania</h1>
          <p className="hero-lead">Homes, apartments, commercial premises, land and investment property. We make every stage of your real estate journey simple, transparent and reliable.</p>
          <div className="btn-row">
            <Link to="/properties" className="btn btn-green btn-lg">Browse properties <Icon name="arrow" /></Link>
            <Link to="/contact" className="btn btn-ghost-light btn-lg">Talk to our team</Link>
          </div>
        </div>
      </section>
      <div className="container hero-search-wrap"><HeroSearch /></div>

      {/* SERVICES STRIP */}
      <section className="section-tight">
        <div className="container">
          <div className="svc-strip">
            {SERVICES.map((s) => (
              <Link to={`/services#${s.slug}`} key={s.slug} className="svc-strip-item">
                <span className="svc-ico"><Icon name={s.icon} size={22} /></span>
                <span><strong>{s.name}</strong><small>Learn more</small></span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURED */}
      <section className="section">
        <div className="container">
          <SectionHead eyebrow="Featured & new" title="Our latest properties for sale and rent"
            text="Homes, apartments, land and commercial space, newly listed with Masaki Green Realty."
            action={<Link to="/properties" className="btn btn-outline">View all properties <Icon name="arrow" /></Link>} />
          <div className="grid-4">{featured.map((p) => <PropertyCard key={p.ref} p={p} />)}</div>
        </div>
      </section>

      {/* CATEGORIES */}
      <section className="section bg-soft">
        <div className="container">
          <SectionHead eyebrow="Property categories" title="Explore by property type" center
            text="From apartments and family homes to offices, retail, industrial and land." />
          <div className="cat-grid">
            {CATEGORIES.map((c) => (
              <Link key={c.slug} to={`/properties?cat=${encodeURIComponent(c.name)}`} className="cat-card">
                <span className="cat-ico"><Icon name={c.icon} size={26} /></span>
                <strong>{c.name}</strong>
                <small>{counts[c.name] ? `${counts[c.name]} sample ${counts[c.name] === 1 ? 'listing' : 'listings'}` : 'Enquire for options'}</small>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* INTRO */}
      <section className="section">
        <div className="container intro">
          <div className="intro-media">
            <PropertyImage img="mgr-0001-11" alt="Five-bedroom house in Madale listed by Masaki Green Realty" label={false} />
            <div className="intro-card">
              <span className="eyebrow">Our mission</span>
              <p>{COMPANY.mission}</p>
            </div>
          </div>
          <div>
            <span className="eyebrow">About Masaki Green Realty</span>
            <h2>More than a transaction, an investment in your future</h2>
            <p className="lead">Masaki Green Realty is a Tanzania-based real estate company headquartered in Masaki, Dar es Salaam, serving clients and property opportunities across Tanzania.</p>
            <p>We connect individuals, families, businesses and investors with suitable property opportunities in both the general and premium market, across residential, commercial and investment property.</p>
            <ul className="ticks">
              <li><Icon name="check" size={18} /> Property sales, rentals, management and advisory</li>
              <li><Icon name="check" size={18} /> Residential, commercial and investment property</li>
              <li><Icon name="check" size={18} /> Guidance from first enquiry to completion</li>
            </ul>
            <Link to="/about" className="btn btn-navy">About us <Icon name="arrow" /></Link>
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section className="section bg-navy">
        <div className="container">
          <SectionHead eyebrow="Our services" title="Professional guidance at every step" center
            text="Whether you are buying, selling, renting or investing, we provide dependable service and professional property guidance." />
          <div className="svc-grid">
            {SERVICES.map((s) => (
              <div className="svc-card" key={s.slug}>
                <span className="svc-ico lg"><Icon name={s.icon} size={26} /></span>
                <h3>{s.name}</h3>
                <p>{s.short}</p>
                <Link to={`/services#${s.slug}`} className="link-arrow">Learn more <Icon name="arrow" size={16} /></Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* WHY US */}
      <section className="section">
        <div className="container">
          <SectionHead eyebrow="Why choose Masaki Green Realty" title="Built on trust, integrity and transparency" center />
          <div className="why-grid">
            {COMPANY.values.map((v, i) => (
              <div className="why" key={v.name}>
                <span className="why-n">0{i + 1}</span>
                <h3>{v.name}</h3>
                <p>{v.text}</p>
              </div>
            ))}
          </div>
          <div className="why-points">
            <div><Icon name="layers" /><span><strong>One partner for every need</strong>Sales, rentals, management and investment advice under one roof.</span></div>
            <div><Icon name="users" /><span><strong>General and premium markets</strong>Options for individuals, families, businesses and investors.</span></div>
            <div><Icon name="shield" /><span><strong>Clear, honest pricing</strong>Every property shown in its listed currency, with no hidden conversions.</span></div>
          </div>
        </div>
      </section>

      {/* DISCOVERY CTA */}
      <section className="section-tight">
        <div className="container">
          <div className="cta-band">
            <div>
              <h2>Not sure where to start?</h2>
              <p>Tell us what you are looking for, your budget and preferred areas, and we will help you find suitable options.</p>
            </div>
            <div className="btn-row">
              <Link to="/properties" className="btn btn-white">Search properties</Link>
              <a href={waLink('Hello Masaki Green Realty, I am looking for a property.')} target="_blank" rel="noopener noreferrer" className="btn btn-ghost-light"><Icon name="whatsapp" /> WhatsApp us</a>
            </div>
          </div>
        </div>
      </section>

      {/* RECENT */}
      <section className="section">
        <div className="container">
          <SectionHead eyebrow="More properties" title="Explore other property types"
            text="Offices, retail, holiday homes and more. These listings are samples showing the range of property we cover."
            action={<Link to="/properties" className="btn btn-outline">Browse all <Icon name="arrow" /></Link>} />
          <div className="grid-4">{more.map((p) => <PropertyCard key={p.ref} p={p} />)}</div>
        </div>
      </section>

      {/* INSIGHTS */}
      <section className="section bg-soft">
        <div className="container">
          <SectionHead eyebrow="Insights" title="Guides for buyers, tenants and owners"
            action={<Link to="/insights" className="btn btn-outline">All insights <Icon name="arrow" /></Link>} />
          <div className="grid-3">
            {ARTICLES.slice(0, 3).map((a) => (
              <Link to={`/insights/${a.slug}`} className="acard" key={a.slug}>
                <div className="acard-media"><PropertyImage img={a.image} alt="" label={false} /></div>
                <div className="acard-body">
                  <span className="acard-cat">{a.category}</span>
                  <h3>{a.title}</h3>
                  <p>{a.summary}</p>
                  <span className="acard-meta"><Icon name="calendar" size={14} /> {fmtDate(a.date)} · {a.readMins} min read</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CONTACT CTA */}
      <section className="section">
        <div className="container contact-cta">
          <div>
            <span className="eyebrow">Get in touch</span>
            <h2>Have a property to sell or let?</h2>
            <p>Talk to us about selling, letting or managing your property. Visit our office in Masaki or contact us directly.</p>
          </div>
          <div className="contact-cta-cards">
            <a href={COMPANY.phoneHref} className="ccard"><Icon name="phone" /><span><small>Call us</small>{COMPANY.phoneDisplay}</span></a>
            <a href={waLink('Hello Masaki Green Realty, I would like to discuss my property.')} target="_blank" rel="noopener noreferrer" className="ccard"><Icon name="whatsapp" /><span><small>WhatsApp</small>{COMPANY.whatsappDisplay}</span></a>
            <a href={`mailto:${COMPANY.email}`} className="ccard"><Icon name="mail" /><span><small>Email</small>{COMPANY.email}</span></a>
            <Link to="/contact" className="ccard"><Icon name="pin" /><span><small>Visit</small>190 Kimweri Road, Masaki</span></Link>
          </div>
        </div>
      </section>
    </>
  )
}
