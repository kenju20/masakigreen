import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import Icon from '../components/Icon'
import PropertyImage from '../components/PropertyImage'
import { Breadcrumbs, usePageTitle } from '../components/Layout'
import { EnquiryForm, Empty, PropertyCard } from '../components/Widgets'
import { COMPANY, waLink } from '../data/company'
import { findProperty, similarProperties, PUBLIC_STATUSES } from '../data/properties'
import { bedsText, formatPrice, fmtDate, fullLocation, rentSuffix, sizeLabel, txLabel } from '../lib/format'
import { useStore } from '../lib/store'
import logo from '../assets/logo-520.jpg'

const imgAlt = (p, i) => `${p.title}, ${p.area} — image ${i + 1} of ${p.gallery.length}`

function Gallery({ p }) {
  const [i, setI] = useState(0)
  const [lb, setLb] = useState(false)
  const n = p.gallery.length
  const go = (d) => setI((x) => (x + d + n) % n)
  useEffect(() => {
    if (!lb) return
    const k = (e) => { if (e.key === 'Escape') setLb(false); if (e.key === 'ArrowRight') go(1); if (e.key === 'ArrowLeft') go(-1) }
    window.addEventListener('keydown', k)
    document.body.style.overflow = 'hidden'
    return () => { window.removeEventListener('keydown', k); document.body.style.overflow = '' }
  })
  return (
    <div className="gallery">
      <div className="gallery-main">
        <button className="gallery-open" onClick={() => setLb(true)} aria-label="Open full-screen gallery">
          <PropertyImage img={p.gallery[i]} alt={imgAlt(p, i)} eager />
        </button>
        {n > 1 && <>
          <button className="gal-nav prev" onClick={() => go(-1)} aria-label="Previous image"><Icon name="left" /></button>
          <button className="gal-nav next" onClick={() => go(1)} aria-label="Next image"><Icon name="right" /></button>
        </>}
        <span className="gal-count"><Icon name="image" size={15} /> {i + 1} / {n}</span>
        <button className="gal-expand" onClick={() => setLb(true)} aria-label="Full screen"><Icon name="expand" size={18} /></button>
      </div>
      {n > 1 && (
        <div className="gallery-thumbs" role="tablist" aria-label="Gallery images">
          {p.gallery.map((g, k) => (
            <button key={k} role="tab" aria-selected={k === i} className={k === i ? 'on' : ''} onClick={() => setI(k)} aria-label={`Show image ${k + 1}`}>
              <PropertyImage img={g} alt="" label={false} />
            </button>
          ))}
        </div>
      )}
      {lb && (
        <div className="lightbox" role="dialog" aria-modal="true" aria-label="Image gallery" onClick={(e) => e.target === e.currentTarget && setLb(false)}>
          <button className="lb-close" onClick={() => setLb(false)} aria-label="Close gallery"><Icon name="x" size={26} /></button>
          <button className="lb-nav prev" onClick={() => go(-1)} aria-label="Previous image"><Icon name="left" size={30} /></button>
          <div className="lb-img"><PropertyImage img={p.gallery[i]} alt={imgAlt(p, i)} /></div>
          <button className="lb-nav next" onClick={() => go(1)} aria-label="Next image"><Icon name="right" size={30} /></button>
          <span className="lb-count">{i + 1} / {n} · {p.title}</span>
        </div>
      )}
    </div>
  )
}

function ShareBox({ p }) {
  const { toast } = useStore()
  const url = window.location.href
  const text = `${p.title} (${p.ref}) — ${COMPANY.name}`
  async function copy() {
    try { await navigator.clipboard.writeText(url); toast('Link copied to clipboard') }
    catch { toast('Copy not available here — select the address bar to copy the link', 'warn') }
  }
  return (
    <div className="share">
      <span>Share</span>
      <button onClick={copy} aria-label="Copy link"><Icon name="link" size={17} /></button>
      <a href={`https://wa.me/?text=${encodeURIComponent(`${text} ${url}`)}`} target="_blank" rel="noopener noreferrer" aria-label="Share on WhatsApp"><Icon name="whatsapp" size={17} /></a>
      <a href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`} target="_blank" rel="noopener noreferrer" aria-label="Share on Facebook" className="txt">f</a>
      <a href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`} target="_blank" rel="noopener noreferrer" aria-label="Share on X" className="txt">X</a>
      <a href={`mailto:?subject=${encodeURIComponent(text)}&body=${encodeURIComponent(url)}`} aria-label="Share by email"><Icon name="mail" size={17} /></a>
    </div>
  )
}

function Brochure({ p, onClose }) {
  const { toast } = useStore()
  useEffect(() => {
    document.body.classList.add('printing-brochure')
    const k = (e) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', k)
    return () => { document.body.classList.remove('printing-brochure'); window.removeEventListener('keydown', k) }
  }, [onClose])
  function print() {
    try { window.print() } catch { toast('Printing is not available in this preview. It works when the site is opened in a normal browser.', 'warn') }
  }
  return (
    <div className="modal" role="dialog" aria-modal="true" aria-label="Property brochure preview" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal-box brochure-wrap">
        <div className="brochure-bar no-print">
          <div><strong>Brochure preview</strong><small>Demonstration: the live website will generate this PDF automatically from the property database.</small></div>
          <div className="btn-row">
            <button className="btn btn-green btn-sm" onClick={print}><Icon name="printer" size={16} /> Print / Save as PDF</button>
            <button className="icon-btn" onClick={onClose} aria-label="Close brochure"><Icon name="x" /></button>
          </div>
        </div>
        <article className="brochure" id="brochure">
          <header className="br-head">
            <img src={logo} alt="Masaki Green Realty" />
            <div><span>{txLabel(p.tx)}</span><strong>Ref {p.ref}</strong></div>
          </header>
          <div className="br-hero"><PropertyImage img={p.gallery[0]} alt={p.title} /></div>
          <div className="br-thumbs">{p.gallery.slice(1, 4).map((g, i) => <PropertyImage key={i} img={g} alt="" label={false} />)}</div>
          <div className="br-title">
            <div><h2>{p.title}</h2><p><Icon name="pin" size={14} /> {fullLocation(p)}</p></div>
            <div className="br-price">{formatPrice(p)}<small>{rentSuffix(p)}</small></div>
          </div>
          <div className="br-cols">
            <div>
              <h3>Description</h3>
              {p.description.map((d, i) => <p key={i}>{d}</p>)}
              <h3>Amenities</h3>
              <ul className="br-amen">{p.amenities.map((a) => <li key={a}>{a}</li>)}</ul>
            </div>
            <div>
              <h3>Specifications</h3>
              <dl className="br-specs">
                <dt>Type</dt><dd>{p.category}</dd>
                {bedsText(p) && <><dt>Bedrooms</dt><dd>{p.bedsLabel || p.beds}</dd></>}
                {p.baths != null && <><dt>Bathrooms</dt><dd>{p.baths}</dd></>}
                {p.size && <><dt>{p.sizeText ? 'Unit sizes' : 'Floor area'}</dt><dd>{p.sizeText || `${p.size.toLocaleString()} m²`}</dd></>}
                {p.unitRate && <><dt>Rate</dt><dd>{p.unitRate}</dd></>}
                {p.land && <><dt>Land size</dt><dd>{p.land.toLocaleString()} m²</dd></>}
                {p.floors && <><dt>Floors</dt><dd>{p.floors}</dd></>}
                <dt>Status</dt><dd>{p.status}</dd>
              </dl>
            </div>
          </div>
          <footer className="br-foot">
            <span><Icon name="phone" size={14} /> {COMPANY.phoneDisplay}</span>
            <span><Icon name="whatsapp" size={14} /> {COMPANY.whatsappDisplay}</span>
            <span><Icon name="mail" size={14} /> {COMPANY.email}</span>
            <span>{COMPANY.domain}</span>
          </footer>
          {p.sample && <p className="br-sample">Sample listing — prepared for presentation purposes only.</p>}
          {p.imageNote && <p className="br-sample">{p.imageNote}</p>}
        </article>
      </div>
    </div>
  )
}

export default function PropertyDetail() {
  const { slug } = useParams()
  const p = findProperty(slug)
  const { saved, compare, toggleSaved, toggleCompare, addRecent } = useStore()
  const [brochure, setBrochure] = useState(false)
  usePageTitle(p ? `${p.title} in ${p.area} — ${p.ref}` : 'Property not found', p ? `${p.short} ${txLabel(p.tx)} in ${p.area}, ${p.city}.` : undefined)
  useEffect(() => { if (p && PUBLIC_STATUSES.includes(p.status)) addRecent(p.ref) }, [p, addRecent])

  if (!p) {
    return (
      <div className="container section">
        <Empty icon="home" title="Property not found" text="This property may have been removed or the link may be incorrect.">
          <Link className="btn btn-green" to="/properties">Browse properties</Link>
        </Empty>
      </div>
    )
  }
  const available = PUBLIC_STATUSES.includes(p.status)
  const similar = similarProperties(p)
  const isSaved = saved.includes(p.ref)
  const inCompare = compare.includes(p.ref)
  const waMsg = `Hello Masaki Green Realty, I am interested in ${p.title} (Ref ${p.ref}). Please share more details.`
  const mapQ = encodeURIComponent(`${p.area}, ${p.city}, Tanzania`)

  return (
    <>
      <div className="detail-top">
        <div className="container">
          <Breadcrumbs items={[['Home', '/'], ['Properties', '/properties'], [p.category, `/properties?cat=${encodeURIComponent(p.category)}`], [p.title]]} />
        </div>
      </div>

      {!available && (
        <div className="container"><div className="status-banner"><Icon name="info" /> <span>This property is <strong>{p.status.toLowerCase()}</strong> and no longer available. See similar properties below, or <Link to="/contact">tell us what you are looking for</Link>.</span></div></div>
      )}

      <section className="section-tight">
        <div className="container">
          <div className="detail-head">
            <div>
              <div className="detail-badges">
                <span className={`badge badge-${p.tx}`}>{txLabel(p.tx)}</span>
                <span className={`badge badge-status s-${p.status.toLowerCase()}`}>{p.status}</span>
                {p.featured && <span className="badge badge-feat"><Icon name="star" size={12} /> Featured</span>}
                {p.isNew && <span className="badge badge-new">New</span>}
                {p.sample && <span className="badge badge-sample">Sample listing</span>}
              </div>
              <h1>{p.title}</h1>
              <p className="detail-loc"><Icon name="pin" size={17} /> {fullLocation(p)} <span className="dot-sep">·</span> Ref <strong>{p.ref}</strong></p>
            </div>
            <div className="detail-head-actions">
              <button className={`btn btn-outline btn-sm ${isSaved ? 'is-on' : ''}`} onClick={() => toggleSaved(p.ref)} aria-pressed={isSaved}><Icon name="heart" size={16} /> {isSaved ? 'Saved' : 'Save'}</button>
              <button className={`btn btn-outline btn-sm ${inCompare ? 'is-on' : ''}`} onClick={() => toggleCompare(p.ref)} aria-pressed={inCompare}><Icon name="compare" size={16} /> {inCompare ? 'In comparison' : 'Compare'}</button>
              <button className="btn btn-outline btn-sm" onClick={() => setBrochure(true)}><Icon name="file" size={16} /> Brochure</button>
            </div>
          </div>

          <div className="detail-layout">
            <div className="detail-main">
              <Gallery p={p} />
              {(p.sample || p.imageNote) && <p className="illus-note"><Icon name="info" size={14} /> {p.imageNote || 'Images are illustrations for this sample listing.'}</p>}

              <div className="spec-bar">
                <div><small>Type</small><strong>{p.category}</strong></div>
                {bedsText(p) && <div><Icon name="bed" /><small>Bedrooms</small><strong>{p.bedsLabel || p.beds}</strong></div>}
                {p.baths != null && <div><Icon name="bath" /><small>Bathrooms</small><strong>{p.baths}</strong></div>}
                {p.size && <div><Icon name="ruler" /><small>{p.sizeText ? 'Unit sizes' : 'Floor area'}</small><strong>{p.sizeText || `${p.size.toLocaleString()} m²`}</strong></div>}
                {p.land && <div><Icon name="map" /><small>Land</small><strong>{sizeLabel({ land: p.land })}</strong></div>}
              </div>

              <div className="detail-block">
                <h2>Overview</h2>
                {p.description.map((d, i) => <p key={i}>{d}</p>)}
                {p.highlights?.length > 0 && (
                  <ul className="highlights">{p.highlights.map((h) => <li key={h}><Icon name="check" size={17} /> {h}</li>)}</ul>
                )}
              </div>

              <div className="detail-block">
                <h2>Specifications</h2>
                <dl className="spec-table">
                  <div><dt>Reference</dt><dd>{p.ref}</dd></div>
                  <div><dt>Property type</dt><dd>{p.category}</dd></div>
                  <div><dt>Transaction</dt><dd>{txLabel(p.tx)}</dd></div>
                  <div><dt>Price</dt><dd>{formatPrice(p)}{rentSuffix(p)}</dd></div>
                  {p.unitRate && <div><dt>Rate</dt><dd>{p.unitRate}</dd></div>}
                  <div><dt>Currency</dt><dd>{p.currency === 'TZS' ? 'Tanzanian Shilling (TZS)' : 'US Dollar (USD)'}</dd></div>
                  {p.priceDisplay !== 'request' && <div><dt>Negotiable</dt><dd>{p.negotiable ? 'Yes' : 'No'}</dd></div>}
                  {bedsText(p) && <div><dt>Bedrooms</dt><dd>{p.bedsLabel || p.beds}</dd></div>}
                  {p.baths != null && <div><dt>Bathrooms</dt><dd>{p.baths}</dd></div>}
                  {p.size && <div><dt>{p.sizeText ? 'Unit sizes' : 'Floor area'}</dt><dd>{p.sizeText || `${p.size.toLocaleString()} m²`}</dd></div>}
                  {p.land && <div><dt>Land size</dt><dd>{p.land.toLocaleString()} m²</dd></div>}
                  {p.floors && <div><dt>Floor / storeys</dt><dd>{p.floors}</dd></div>}
                  <div><dt>Location</dt><dd>{fullLocation(p)}</dd></div>
                  <div><dt>Availability</dt><dd>{p.status}</dd></div>
                  <div><dt>Listed</dt><dd>{fmtDate(p.added)}</dd></div>
                </dl>
              </div>

              <div className="detail-block">
                <h2>Amenities and features</h2>
                <ul className="amen-list">{p.amenities.map((a) => <li key={a}><Icon name="check" size={16} /> {a}</li>)}</ul>
              </div>

              <div className="detail-block">
                <h2>Location</h2>
                <div className="map-card">
                  <svg viewBox="0 0 600 260" aria-hidden="true" className="map-illus">
                    <rect width="600" height="260" fill="#eef1f4" />
                    <path d="M0 180 C120 150 200 210 320 170 S520 120 600 140" stroke="#dfe5ec" strokeWidth="28" fill="none" />
                    <path d="M60 0 L140 260 M300 0 L260 260 M0 80 L600 60 M420 0 L520 260" stroke="#fff" strokeWidth="10" />
                    <circle cx="300" cy="118" r="60" fill="#238411" opacity=".12" />
                  </svg>
                  <div className="map-pin"><Icon name="pin" size={30} /></div>
                  <div className="map-info">
                    <strong>{p.area}, {p.city}</strong>
                    <span>Approximate area shown. The exact address is shared on enquiry.</span>
                    <a href={`https://www.google.com/maps/search/?api=1&query=${mapQ}`} target="_blank" rel="noopener noreferrer" className="link-arrow">View area on Google Maps <Icon name="arrow" size={15} /></a>
                  </div>
                </div>
              </div>

              <div className="detail-block" id="enquire">
                {available ? <EnquiryForm property={p} title="Enquire about this property" /> : (
                  <Empty icon="home" title="This property is no longer available" text="Contact us and we will help you find similar options.">
                    <Link className="btn btn-green" to="/contact">Contact us</Link>
                  </Empty>
                )}
              </div>
            </div>

            <aside className="detail-side">
              <div className="price-card">
                <small>{txLabel(p.tx)} · {p.currency}</small>
                <div className="price-big">{formatPrice(p)}<span>{rentSuffix(p)}</span></div>
                {p.negotiable && p.priceDisplay !== 'request' && <span className="neg">Negotiable</span>}
                {p.unitRate && <p className="unit-rate">{p.unitRate}</p>}
                <div className={`status-line s-${p.status.toLowerCase()}`}><span className="sdot" /> {p.status}</div>
                <div className="price-card-actions">
                  {available && <a href="#enquire" onClick={(e) => { e.preventDefault(); document.getElementById('enquire')?.scrollIntoView({ behavior: 'smooth' }) }} className="btn btn-green btn-block">Enquire now</a>}
                  <a href={waLink(waMsg)} target="_blank" rel="noopener noreferrer" className="btn btn-wa btn-block"><Icon name="whatsapp" /> WhatsApp</a>
                  <a href={COMPANY.phoneHref} className="btn btn-outline btn-block"><Icon name="phone" /> {COMPANY.phoneDisplay}</a>
                </div>
                <button className="link-btn brochure-link" onClick={() => setBrochure(true)}><Icon name="file" size={16} /> View property brochure</button>
                <ShareBox p={p} />
              </div>
              <div className="side-note">
                <Icon name="shield" size={20} />
                <p>Quote reference <strong>{p.ref}</strong> when you contact us so we can identify this property straight away.</p>
              </div>
            </aside>
          </div>
        </div>
      </section>

      {similar.length > 0 && (
        <section className="section bg-soft">
          <div className="container">
            <h2 className="h-md">Similar properties</h2>
            <div className="grid-3">{similar.map((s) => <PropertyCard key={s.ref} p={s} />)}</div>
          </div>
        </section>
      )}

      <div className="mobile-cta no-print">
        <a href={waLink(waMsg)} target="_blank" rel="noopener noreferrer" className="btn btn-wa"><Icon name="whatsapp" /> WhatsApp</a>
        <a href={COMPANY.phoneHref} className="btn btn-outline"><Icon name="phone" /> Call</a>
        {available && <a href="#enquire" onClick={(e) => { e.preventDefault(); document.getElementById('enquire')?.scrollIntoView({ behavior: 'smooth' }) }} className="btn btn-green">Enquire</a>}
      </div>

      {brochure && <Brochure p={p} onClose={() => setBrochure(false)} />}
    </>
  )
}
