import { useMemo, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import Icon from '../components/Icon'
import PropertyImage from '../components/PropertyImage'
import { Breadcrumbs, PageHero, SectionHead, usePageTitle } from '../components/Layout'
import { Accordion, EnquiryForm, Empty } from '../components/Widgets'
import { COMPANY, SERVICES, waLink } from '../data/company'
import { ARTICLES, ARTICLE_CATEGORIES, findArticle } from '../data/articles'
import { FAQ_GROUPS } from '../data/faqs'
import { fmtDate } from '../lib/format'

const MAPS_URL = 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent('190 Kimweri Road, Masaki, Dar es Salaam, Tanzania')

/* ================= SERVICES ================= */
export function Services() {
  usePageTitle('Our Services', 'Property sales, property rentals, property management and real estate investment advisory in Tanzania.')
  const [interest, setInterest] = useState(SERVICES[0].interest)
  const [formKey, setFormKey] = useState(0)
  function enquire(s) {
    setInterest(s.interest); setFormKey((k) => k + 1)
    setTimeout(() => document.getElementById('service-enquiry')?.scrollIntoView({ behavior: 'smooth' }), 30)
  }
  return (
    <>
      <PageHero eyebrow="Our services" title="Real estate services for every stage" crumbs={[['Home', '/'], ['Services']]}
        text="Buying, selling, renting, managing or investing: we provide dependable service and professional property guidance." />
      <div className="container svc-jump">
        {SERVICES.map((s) => <a key={s.slug} href={`#/services#${s.slug}`} onClick={(e) => { e.preventDefault(); document.getElementById(s.slug)?.scrollIntoView({ behavior: 'smooth' }) }}><Icon name={s.icon} size={18} /> {s.name}</a>)}
      </div>
      {SERVICES.map((s, i) => (
        <section key={s.slug} id={s.slug} className={`section svc-detail ${i % 2 ? 'bg-soft' : ''}`}>
          <div className={`container svc-detail-in ${i % 2 ? 'rev' : ''}`}>
            <div className="svc-detail-media">
              <PropertyImage img={['mgr-0002-1', 'mgr-0001-2', 'mgr-0007-1', 'mgr-0003-1'][i]} alt="" label={false} />
              <span className="svc-num">0{i + 1}</span>
            </div>
            <div>
              <span className="svc-ico lg"><Icon name={s.icon} size={26} /></span>
              <h2>{s.name}</h2>
              <p className="lead">{s.short}</p>
              {s.long.map((t, k) => <p key={k}>{t}</p>)}
              <ul className="ticks">{s.points.map((pt) => <li key={pt}><Icon name="check" size={18} /> {pt}</li>)}</ul>
              <div className="btn-row">
                <button className="btn btn-green" onClick={() => enquire(s)}>{s.cta}</button>
                <a className="btn btn-outline" href={waLink(`Hello Masaki Green Realty, I would like to ask about ${s.name}.`)} target="_blank" rel="noopener noreferrer"><Icon name="whatsapp" /> WhatsApp</a>
              </div>
            </div>
          </div>
        </section>
      ))}
      <section className="section" id="service-enquiry">
        <div className="container narrow">
          <SectionHead eyebrow="Service enquiry" title="Tell us how we can help" center text="Choose the service you are interested in and send us a few details." />
          <EnquiryForm key={formKey} defaultType={interest} title="Service enquiry" />
        </div>
      </section>
    </>
  )
}

/* ================= ABOUT ================= */
export function About() {
  usePageTitle('About Us', 'Masaki Green Realty is a Tanzania-based real estate company headquartered in Masaki, Dar es Salaam.')
  return (
    <>
      <PageHero eyebrow="About us" title="Your trusted property partner in Tanzania" crumbs={[['Home', '/'], ['About Us']]}
        text="Professional property sales, rentals, property management and investment advisory." />
      <section className="section">
        <div className="container intro">
          <div className="intro-media">
            <PropertyImage img="mgr-0004-1" alt="Amber Coast Residences, Masaki (artist’s impression)" label={false} />
          </div>
          <div>
            <span className="eyebrow">Company overview</span>
            <h2>Making the property journey simple, transparent and reliable</h2>
            <p className="lead">Masaki Green Realty is a Tanzania-based real estate company headquartered in Masaki, Dar es Salaam, serving clients and property opportunities across Tanzania.</p>
            <p>We provide professional real estate services covering property sales, rentals, property management and investment advisory. Our focus is to connect individuals, families, businesses and investors with suitable property opportunities while making every stage of the real estate journey simple, transparent and reliable.</p>
            <p>Whether buying, selling, renting or investing, we are committed to providing dependable service and professional property guidance.</p>
          </div>
        </div>
      </section>

      <section className="section bg-soft">
        <div className="container about-us">
          <div>
            <span className="eyebrow">About us</span>
            <h2>More than a transaction</h2>
            <p>At Masaki Green Realty, we believe that finding the right property is more than a transaction; it is an important investment in the future.</p>
            <p>We serve a diverse market, from individuals and families seeking suitable homes to businesses and investors exploring residential and commercial property opportunities.</p>
            <p>Through our commitment to trust, integrity and transparency, we aim to build lasting relationships and deliver real estate solutions that meet our clients’ needs. Our goal is to make every property journey straightforward, rewarding and worthwhile.</p>
          </div>
          <div className="mv-cards">
            <div className="mv-card navy"><span className="eyebrow eyebrow-light">Our mission</span><p>{COMPANY.mission}</p></div>
            <div className="mv-card green"><span className="eyebrow eyebrow-light">Our vision</span><p>{COMPANY.vision}</p></div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <SectionHead eyebrow="Core values" title="What we stand for" center />
          <div className="why-grid">
            {COMPANY.values.map((v, i) => (
              <div className="why" key={v.name}><span className="why-n">0{i + 1}</span><h3>{v.name}</h3><p>{v.text}</p></div>
            ))}
          </div>
        </div>
      </section>

      <section className="section bg-navy">
        <div className="container positioning">
          <div>
            <span className="eyebrow eyebrow-light">Business positioning &amp; market coverage</span>
            <h2>Based in Masaki. Serving clients across Tanzania.</h2>
            <p>Based in Masaki, Dar es Salaam, Masaki Green Realty serves clients and property opportunities across Tanzania. Our market approach covers both general and premium real estate, including residential, commercial and investment properties.</p>
            <div className="tag-row">
              {['General market', 'Premium market', 'Residential', 'Commercial', 'Investment'].map((t) => <span key={t}>{t}</span>)}
            </div>
          </div>
          <div className="commit-card">
            <h3>Our commitment</h3>
            <p>We are committed to putting our clients first, maintaining professional standards and building relationships founded on trust and transparency.</p>
            <p>From the first enquiry to the completion of a property transaction, we aim to provide reliable guidance and a positive customer experience.</p>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container contact-cta">
          <div>
            <span className="eyebrow">Contact</span>
            <h2>Visit or contact our team</h2>
            <p>{COMPANY.addressLine}</p>
            <div className="btn-row"><Link to="/contact" className="btn btn-green">Contact us</Link><Link to="/services" className="btn btn-outline">Our services</Link></div>
          </div>
          <div className="contact-cta-cards">
            <a href={COMPANY.phoneHref} className="ccard"><Icon name="phone" /><span><small>Telephone</small>{COMPANY.phoneDisplay}</span></a>
            <a href={waLink()} target="_blank" rel="noopener noreferrer" className="ccard"><Icon name="whatsapp" /><span><small>WhatsApp</small>{COMPANY.whatsappDisplay}</span></a>
            <a href={`mailto:${COMPANY.email}`} className="ccard"><Icon name="mail" /><span><small>Email</small>{COMPANY.email}</span></a>
            <a href={COMPANY.website} className="ccard" target="_blank" rel="noopener noreferrer"><Icon name="link" /><span><small>Website</small>{COMPANY.domain}</span></a>
          </div>
        </div>
      </section>
    </>
  )
}

/* ================= INSIGHTS ================= */
function ArticleCard({ a }) {
  return (
    <Link to={`/insights/${a.slug}`} className="acard">
      <div className="acard-media"><PropertyImage img={a.image} alt="" label={false} /></div>
      <div className="acard-body">
        <span className="acard-cat">{a.category}</span>
        <h3>{a.title}</h3>
        <p>{a.summary}</p>
        <span className="acard-meta"><Icon name="calendar" size={14} /> {fmtDate(a.date)} · {a.readMins} min read</span>
      </div>
    </Link>
  )
}

export function Insights() {
  usePageTitle('Insights', 'Guides on buying, renting, property management and investment in Tanzania.')
  const [cat, setCat] = useState('')
  const [q, setQ] = useState('')
  const [page, setPage] = useState(1)
  const list = useMemo(() => ARTICLES.filter((a) => (!cat || a.category === cat) && (!q.trim() || (a.title + a.summary + a.tags.join(' ')).toLowerCase().includes(q.toLowerCase().trim()))), [cat, q])
  const PER = 6
  const pages = Math.max(1, Math.ceil(list.length / PER))
  const shown = list.slice((page - 1) * PER, page * PER)
  const [lead, ...rest] = shown
  const usedCats = ARTICLE_CATEGORIES.filter((c) => ARTICLES.some((a) => a.category === c))
  return (
    <>
      <PageHero eyebrow="Insights" title="Property insights and guides" crumbs={[['Home', '/'], ['Insights']]}
        text="Practical guidance for buyers, tenants, owners and investors." />
      <section className="section-tight">
        <div className="container">
          <div className="blog-bar">
            <div className="chip-row" role="tablist" aria-label="Article categories">
              <button className={!cat ? 'on' : ''} onClick={() => { setCat(''); setPage(1) }}>All</button>
              {usedCats.map((c) => <button key={c} className={cat === c ? 'on' : ''} onClick={() => { setCat(c); setPage(1) }}>{c}</button>)}
            </div>
            <label className="blog-search"><Icon name="search" size={18} /><span className="sr-only">Search articles</span>
              <input placeholder="Search articles" value={q} onChange={(e) => { setQ(e.target.value); setPage(1) }} /></label>
          </div>
          <p className="sample-note left"><Icon name="info" size={15} /> Sample articles prepared for this presentation.</p>
          {!list.length ? (
            <Empty title="No articles found" text="Try a different search or category.">
              <button className="btn btn-green" onClick={() => { setCat(''); setQ('') }}>Show all articles</button>
            </Empty>
          ) : (
            <>
              {lead && (
                <Link to={`/insights/${lead.slug}`} className="acard-lead">
                  <div className="acard-media"><PropertyImage img={lead.image} alt="" label={false} /></div>
                  <div className="acard-body">
                    <span className="acard-cat">{lead.category}</span>
                    <h2>{lead.title}</h2>
                    <p>{lead.summary}</p>
                    <span className="acard-meta"><Icon name="calendar" size={14} /> {fmtDate(lead.date)} · {lead.readMins} min read</span>
                    <span className="link-arrow">Read article <Icon name="arrow" size={16} /></span>
                  </div>
                </Link>
              )}
              <div className="grid-3">{rest.map((a) => <ArticleCard key={a.slug} a={a} />)}</div>
              {pages > 1 && (
                <nav className="pagination" aria-label="Pagination">
                  {Array.from({ length: pages }, (_, i) => i + 1).map((n) => <button key={n} className={n === page ? 'on' : ''} onClick={() => setPage(n)}>{n}</button>)}
                </nav>
              )}
            </>
          )}
        </div>
      </section>
    </>
  )
}

export function Article() {
  const { slug } = useParams()
  const a = findArticle(slug)
  usePageTitle(a ? a.title : 'Article not found', a?.summary)
  if (!a) return <div className="container section"><Empty title="Article not found"><Link className="btn btn-green" to="/insights">All insights</Link></Empty></div>
  const related = ARTICLES.filter((x) => x.slug !== a.slug).sort((x, y) => (y.category === a.category) - (x.category === a.category)).slice(0, 3)
  const svc = a.category.includes('Rent') ? SERVICES[1] : a.category.includes('Management') ? SERVICES[2] : a.category.includes('Investment') || a.category.includes('Market') ? SERVICES[3] : SERVICES[0]
  return (
    <>
      <article>
        <header className="article-head">
          <div className="container narrow">
            <Breadcrumbs items={[['Home', '/'], ['Insights', '/insights'], [a.category]]} />
            <span className="acard-cat">{a.category}</span>
            <h1>{a.title}</h1>
            <p className="article-sum">{a.summary}</p>
            <div className="article-meta">
              <span><Icon name="users" size={15} /> Masaki Green Realty team</span>
              <span><Icon name="calendar" size={15} /> Published {fmtDate(a.date)}</span>
              <span><Icon name="clock" size={15} /> {a.readMins} min read</span>
            </div>
          </div>
        </header>
        <div className="container narrow">
          <div className="article-img"><PropertyImage img={a.image} alt="" /></div>
          <p className="notice-inline"><Icon name="info" size={16} /> Sample article for presentation. General information only — not legal or financial advice.</p>
          <div className="prose">
            {a.body.map((b, i) => b.h ? <h2 key={i}>{b.h}</h2> : b.list ? <ul key={i}>{b.list.map((l) => <li key={l}>{l}</li>)}</ul> : <p key={i}>{b.p}</p>)}
          </div>
          <div className="article-tags">{a.tags.map((t) => <span key={t}>#{t}</span>)}</div>
          <div className="article-cta">
            <div><h3>Need help with {svc.name.toLowerCase()}?</h3><p>Our team can guide you through the next step.</p></div>
            <div className="btn-row"><Link to={`/services#${svc.slug}`} className="btn btn-green">{svc.name}</Link><Link to="/properties" className="btn btn-outline">Browse properties</Link></div>
          </div>
          <div className="share left">
            <span>Share this article</span>
            <a href={`https://wa.me/?text=${encodeURIComponent(`${a.title} ${window.location.href}`)}`} target="_blank" rel="noopener noreferrer" aria-label="Share on WhatsApp"><Icon name="whatsapp" size={17} /></a>
            <a href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}`} target="_blank" rel="noopener noreferrer" aria-label="Share on Facebook" className="txt">f</a>
            <a href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(a.title)}&url=${encodeURIComponent(window.location.href)}`} target="_blank" rel="noopener noreferrer" aria-label="Share on X" className="txt">X</a>
            <a href={`mailto:?subject=${encodeURIComponent(a.title)}&body=${encodeURIComponent(window.location.href)}`} aria-label="Share by email"><Icon name="mail" size={17} /></a>
          </div>
        </div>
      </article>
      <section className="section bg-soft">
        <div className="container">
          <h2 className="h-md">Related articles</h2>
          <div className="grid-3">{related.map((r) => <ArticleCard key={r.slug} a={r} />)}</div>
        </div>
      </section>
    </>
  )
}

/* ================= FAQ ================= */
export function FAQ() {
  usePageTitle('Frequently Asked Questions')
  const [group, setGroup] = useState(0)
  return (
    <>
      <PageHero eyebrow="FAQ" title="Frequently asked questions" crumbs={[['Home', '/'], ['FAQ']]}
        text="Answers to common questions about our services, properties and this website." />
      <section className="section-tight">
        <div className="container faq-layout">
          <nav className="faq-nav" aria-label="FAQ topics">
            {FAQ_GROUPS.map((g, i) => <button key={g.group} className={i === group ? 'on' : ''} onClick={() => setGroup(i)}>{g.group}<Icon name="right" size={16} /></button>)}
            <div className="faq-help">
              <h3>Still have a question?</h3>
              <p>Our team is happy to help.</p>
              <a className="btn btn-green btn-block" href={waLink('Hello Masaki Green Realty, I have a question.')} target="_blank" rel="noopener noreferrer"><Icon name="whatsapp" /> WhatsApp us</a>
              <Link className="btn btn-outline btn-block" to="/contact">Contact us</Link>
            </div>
          </nav>
          <div>
            <h2 className="h-md">{FAQ_GROUPS[group].group}</h2>
            <Accordion key={group} items={FAQ_GROUPS[group].items} idPrefix={`faq${group}`} />
          </div>
        </div>
      </section>
    </>
  )
}

/* ================= CONTACT ================= */
export function Contact() {
  usePageTitle('Contact Us', 'Contact Masaki Green Realty: 190 Kimweri Road, Masaki, Dar es Salaam. Telephone and WhatsApp +255 657 633 698.')
  return (
    <>
      <PageHero eyebrow="Contact us" title="Let’s talk property" crumbs={[['Home', '/'], ['Contact']]}
        text="Call, WhatsApp, email or visit our office in Masaki. Or send an enquiry below." />
      <section className="section-tight">
        <div className="container contact-layout">
          <div className="contact-info">
            <a href={COMPANY.phoneHref} className="cinfo"><span className="svc-ico"><Icon name="phone" /></span><span><small>Telephone</small><strong>{COMPANY.phoneDisplay}</strong></span></a>
            <a href={waLink('Hello Masaki Green Realty, I have a property enquiry.')} target="_blank" rel="noopener noreferrer" className="cinfo"><span className="svc-ico"><Icon name="whatsapp" /></span><span><small>WhatsApp</small><strong>{COMPANY.whatsappDisplay}</strong></span></a>
            <a href={`mailto:${COMPANY.email}`} className="cinfo"><span className="svc-ico"><Icon name="mail" /></span><span><small>Email</small><strong>{COMPANY.email}</strong></span></a>
            <div className="cinfo"><span className="svc-ico"><Icon name="pin" /></span><span><small>Office</small><strong>{COMPANY.address[0]}, {COMPANY.address[1]}<br />{COMPANY.address[2]}</strong></span></div>
            <div className="map-card office-map">
              <svg viewBox="0 0 600 300" aria-hidden="true" className="map-illus">
                <rect width="600" height="300" fill="#eef1f4" />
                <path d="M0 230 C150 190 250 260 380 210 S560 160 600 175" stroke="#d9e1ea" strokeWidth="34" fill="none" />
                <path d="M80 0 L170 300 M330 0 L290 300 M0 100 L600 80 M470 0 L560 300" stroke="#fff" strokeWidth="12" />
                <circle cx="300" cy="135" r="70" fill="#238411" opacity=".12" />
              </svg>
              <div className="map-pin"><Icon name="pin" size={32} /></div>
              <div className="map-info">
                <strong>Masaki Green Realty</strong>
                <span>{COMPANY.addressLine}</span>
                <a href={MAPS_URL} target="_blank" rel="noopener noreferrer" className="link-arrow">Open in Google Maps <Icon name="arrow" size={15} /></a>
              </div>
            </div>
          </div>
          <EnquiryForm title="Send us an enquiry" />
        </div>
      </section>
    </>
  )
}

/* ================= LEGAL ================= */
const LEGAL = {
  privacy: {
    title: 'Privacy Policy',
    sections: [
      ['Who we are', `${COMPANY.name}, ${COMPANY.addressLine}. Contact: ${COMPANY.email}, ${COMPANY.phoneDisplay}.`],
      ['Information we collect', 'When you send an enquiry we collect the details you provide: your name, phone number, email address, the property or service you are interested in, and your message. We collect only the information needed to respond to you.'],
      ['How we use it', 'We use your information to respond to your enquiry, arrange viewings, and provide the services you ask about. We do not sell your personal information.'],
      ['Saved properties and browser storage', 'Saved properties, comparison selections and recently viewed properties are stored in your own browser on your device. They are not sent to us. You can clear them at any time by clearing your browser data.'],
      ['How long we keep information', 'We keep enquiry information only for as long as needed for the purpose it was collected, or as required by applicable law.'],
      ['Your choices', `You may ask us to access, correct or delete the personal information we hold about you by contacting ${COMPANY.email}.`],
    ],
  },
  terms: {
    title: 'Terms and Conditions',
    sections: [
      ['Use of this website', `This website is operated by ${COMPANY.name}. By using it you agree to these terms.`],
      ['Property information', 'We aim to keep property information accurate and up to date, but details such as availability, price and specifications may change. Information on this website does not form part of any offer or contract. Please confirm all details with us before making any decision.'],
      ['Prices and currencies', 'Prices are shown in the currency in which each property is listed (TZS or USD). Prices are not converted between currencies.'],
      ['Images', 'Images are provided for illustration. Where an image is indicative rather than of the specific property, this will be noted.'],
      ['Listings', `Properties on this website are listed and managed by ${COMPANY.name}. Third-party property submissions are not accepted through this website.`],
      ['Links to other websites', 'We are not responsible for the content of external websites linked from this site, including WhatsApp, social media and map services.'],
    ],
  },
  cookies: {
    title: 'Cookies and Browser Storage',
    sections: [
      ['What this website stores', 'This website uses your browser’s local storage to remember your saved properties, comparison selections and recently viewed properties on your device, and session storage to remember that you dismissed the site notice.'],
      ['Analytics', 'No analytics or advertising cookies are used at present. If analytics tools such as Google Analytics are added in future, this page will be updated and your consent will be requested where required.'],
      ['Managing storage', 'You can clear stored information at any time through your browser settings. The website will continue to work without it.'],
    ],
  },
}

export function Legal({ page }) {
  const d = LEGAL[page]
  usePageTitle(d.title)
  return (
    <>
      <PageHero eyebrow="Legal" title={d.title} crumbs={[['Home', '/'], [d.title]]} />
      <section className="section-tight">
        <div className="container narrow">
          <p className="notice-inline warn"><Icon name="info" size={18} /> <span><strong>Draft for review.</strong> This text is a starting draft for the presentation and must be reviewed by a qualified legal adviser before the website goes live.</span></p>
          <div className="prose">
            {d.sections.map(([h, t]) => <section key={h}><h2>{h}</h2><p>{t}</p></section>)}
          </div>
        </div>
      </section>
    </>
  )
}

export function NotFound() {
  usePageTitle('Page not found')
  return (
    <div className="container section">
      <Empty icon="map" title="Page not found" text="The page you are looking for does not exist or has moved.">
        <div className="btn-row center"><Link className="btn btn-green" to="/">Go to homepage</Link><Link className="btn btn-outline" to="/properties">Browse properties</Link></div>
      </Empty>
    </div>
  )
}

